# Rendu numéro 2 : avancement

Voir document pdf envoyé sur discord, ou suivre ce lien: https://typst.app/project/r0KSeZmQ3mFtl1o1htvZCl


## License
- Code: Apache-2.0
- Everything else, in particular documentation and measurements: CC-BY-SA-4.0

package fizz;

public class Fizz {
	public Fizz() {

	}

	public String calculateAt(int i) {
		StringBuilder sb = new StringBuilder();
		if (i % 3 != 0 && i % 5 != 0) {
			sb.append(Integer.toString(i));
		} else if (i % 3 == 0) {
			sb.append("Fizz");
		}
		if (i % 5 == 0) {
			sb.append("Buzz");
		}
		return sb.toString();
	}

}

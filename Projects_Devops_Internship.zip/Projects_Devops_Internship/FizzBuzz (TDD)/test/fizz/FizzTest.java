package fizz;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FizzTest {
	Fizz fizz;

	@BeforeEach
	void setUp() throws Exception {
		fizz = new Fizz();
	}

	@Test
	void premierValeurEgale1() {
		assertEquals(fizz.calculateAt(1), "1");
	}

	@Test
	void deuxiemeValeurEgale2() {
		assertEquals(fizz.calculateAt(2), "2");
	}

	@Test
	void multiple3EgaleFizz() {
		assertEquals(fizz.calculateAt(3), "Fizz");
		assertEquals(fizz.calculateAt(6), "Fizz");
	}

	@Test
	void multiple5EgaleBuzz() {
		assertEquals(fizz.calculateAt(5), "Buzz");
		assertEquals(fizz.calculateAt(20), "Buzz");
	}

	@Test
	void multiple3Et5EgaleFizzBuzz() {
		assertEquals(fizz.calculateAt(15), "FizzBuzz");
		assertEquals(fizz.calculateAt(45), "FizzBuzz");
	}
}

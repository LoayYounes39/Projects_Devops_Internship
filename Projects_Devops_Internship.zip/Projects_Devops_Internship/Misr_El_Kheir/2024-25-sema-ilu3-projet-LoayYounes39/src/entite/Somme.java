/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entite;

/**
 *
 * @author loayyounes39
 */
public class Somme {
    private int sommeACollecte; 
    private int sommeDejaCollecte; 

    public Somme(int sommeACollecte, int sommeDejaCollecte) {
        this.sommeACollecte = sommeACollecte;
        this.sommeDejaCollecte = sommeDejaCollecte;
    }

    public int getSommeACollecte() {
        return sommeACollecte;
    }

    public int getSommeDejaCollecte() {
        return sommeDejaCollecte;
    }

    public void setSommeDejaCollecte(int sommeDejaCollecte) {
        this.sommeDejaCollecte = sommeDejaCollecte;
    }

    @Override
    public String toString() {
        return sommeACollecte + ";" + sommeDejaCollecte;
    }

    
    
   
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entite;

/**
 *
 * @author loayyounes39
 */
public class Personne implements Comparable {
    private String nom; 

    public Personne(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    @Override
    public String toString() {
        return nom.replace(" ", "");
    }

    @Override
    public int compareTo(Object o) {
        if (o instanceof Personne){
            return ((Personne) o).getNom().compareTo (nom);
        }
        return -1;
    }
    
}

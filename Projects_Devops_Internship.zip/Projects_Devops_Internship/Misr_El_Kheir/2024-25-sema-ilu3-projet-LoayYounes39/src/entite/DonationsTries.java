/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entite;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 *
 * @author loayyounes39
 */
public class DonationsTries implements Iterable<Donation>{

    private final TreeSet<Donation> treeSet;

    public DonationsTries() {
        Comparator comparator = new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                if (o1 instanceof Donation && o2 instanceof Donation){
                    Donation don1 = (Donation) o1;
                    Donation don2 = (Donation) o2;
                    if (don1.getDateButoir()[2] != don2.getDateButoir()[2]) {
                        return Integer.compare(don1.getDateButoir()[2], don2.getDateButoir()[2]);
                    }
                    if (don1.getDateButoir()[1] != don2.getDateButoir()[1]) {
                        return Integer.compare(don1.getDateButoir()[1], don2.getDateButoir()[1]);
                    }
                    int val = Integer.compare(don1.getDateButoir()[0], don2.getDateButoir()[0]); 
                    if (val == 0){
                        return don1.getNom().compareTo(don2.getNom());
                    }
                    return val;
                }
                throw new ClassCastException("Cannot compare Donation with non-Donation object");
            }
        };
        treeSet = new TreeSet<Donation>(comparator);
    }
    
    public void add(Donation element) {
        treeSet.add(element);
    }

    public SortedSet<Donation> chercherDonationsEntreDates(int[] dateDebut, int[] dateFin){
        Donation donation1 = new Donation("don 1", dateDebut, 0, new HashMap<Personne, Somme>(), 0, false);
        Donation donation2 = new Donation("don 2", dateFin, 0, new HashMap<Personne, Somme>(), 0, false);
        return treeSet.subSet(donation1, true, donation2, true);
    }
    
    public boolean remove(Donation element) {
        return treeSet.remove(element);
    }

    @Override
    public Iterator<Donation> iterator() {
        return treeSet.iterator();
    }

}

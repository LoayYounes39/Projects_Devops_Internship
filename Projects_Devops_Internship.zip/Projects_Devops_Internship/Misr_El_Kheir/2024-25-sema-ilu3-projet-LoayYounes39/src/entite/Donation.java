/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entite;

import static java.lang.Integer.hashCode;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;

/**
 *
 * @author loayyounes39
 */
public class Donation  {
    private String nom; 
    private int identifiant;
    private int sommeCollecte; 
    private int sommeTotal;
    private int dateButoir[];
    private boolean estDonationTerminee;
    private HashMap<Personne, Somme> mapPersonneSomme;

    public Donation(String nom, int[] dateButoir, int sommeTotal, HashMap<Personne, Somme> mapPersonneSomme, int identifiant, boolean estDonationTerminee) {
        this.nom = nom;
        sommeCollecte = 0;
        this.sommeTotal = sommeTotal;
        this.mapPersonneSomme = mapPersonneSomme;
        this.dateButoir = dateButoir;
        this.identifiant = identifiant;
        this.estDonationTerminee = estDonationTerminee;
        
    }

    public String getNom() {
        return nom;
    }

    public int getSommeCollecte() {
        return sommeCollecte;
    }

    public int getSommeTotal() {
        return sommeTotal;
    }

    public void setSommeCollecte(int sommeCollecte) {
        this.sommeCollecte = sommeCollecte;
    }

    public void setSommeTotal(int sommeTotal) {
        this.sommeTotal = sommeTotal;
    }

    public int[] getDateButoir() {
        return dateButoir;
    }

    public HashMap<Personne, Somme> getMapPersonneSomme() {
        return mapPersonneSomme;
    }


    public void setDateButoir(int[] dateButoir) {
        this.dateButoir = dateButoir;
    }

    public void setMapPersonneSomme(HashMap<Personne, Somme> mapPersonneSomme) {
        this.mapPersonneSomme = mapPersonneSomme;
    }

    public int getIdentifiant() {
        return identifiant;
    }

    public boolean isEstDonationTerminee() {
        return estDonationTerminee;
    }

    public void setEstDonationTerminee(boolean estDonationTerminee) {
        this.estDonationTerminee = estDonationTerminee;
    }
    
    
    
    

    @Override
    public int hashCode() {
        Integer identifiantInt = (Integer) identifiant;
        return identifiantInt.hashCode() * 31;
    }
    

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Donation){
            return hashCode() == obj.hashCode();
        } 
        throw new ClassCastException("Cannot compare Donation with non-Donation object");
    }



    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(identifiant).append(" ");
        sb.append(nom.replace(" ","")).append(" ");
        sb.append(sommeCollecte).append(" ");
        sb.append(sommeTotal).append(" ");
        sb.append(dateButoir[0]).append(";").append(dateButoir[1]).append(";").append(dateButoir[2]).append(";").append(" ");
        for (Personne personne : mapPersonneSomme.keySet()){
            sb.append("#").append(personne.toString()).append(";").append(mapPersonneSomme.get(personne).toString());
        }
        sb.append(" ").append(estDonationTerminee);
        return sb.toString();
    }
    
}

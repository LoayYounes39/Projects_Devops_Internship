/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entite;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeMap;
import java.util.TreeSet;
import jdk.jfr.Percentage;

/**
 *
 * @author loayyounes39
 */
public class GestionnaireDonations {
    private TreeMap<Personne, DonationsTries> mapPersonneDonations;
    private HashSet <Donation> ensembleDonation;

    public GestionnaireDonations() {
       
        mapPersonneDonations = new TreeMap<>();
        ensembleDonation = new HashSet<Donation>();
    }
    

    public TreeMap<Personne, DonationsTries> getMapPersonneDonations() {
        return mapPersonneDonations;
    }
    
    public DonationsTries getDonationsPersonne(Personne personne){
        return mapPersonneDonations.get(personne);
    }

    public void setMapPersonneDonations(TreeMap<Personne, DonationsTries> mapPersonneDonations) {
        this.mapPersonneDonations = mapPersonneDonations;
    }   

    public HashSet<Donation> getEnsembleDonation() {
        return ensembleDonation;
    }

    public void setEnsembleDonation(HashSet<Donation> ensembleDonation) {
        this.ensembleDonation = ensembleDonation;
    }
    
    
}

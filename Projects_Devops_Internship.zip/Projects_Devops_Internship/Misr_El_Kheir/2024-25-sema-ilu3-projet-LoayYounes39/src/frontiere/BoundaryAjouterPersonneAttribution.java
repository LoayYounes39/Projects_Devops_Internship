/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frontiere;

import controleur.ControlAjouterDonation;
import controleur.ControlAjouterPersonneAttribution;

/**
 *
 * @author loayyounes39
 */
public class BoundaryAjouterPersonneAttribution {
    private ControlAjouterPersonneAttribution controlPersonneAttribution;
    private ControlAjouterDonation controlDonation;

    public BoundaryAjouterPersonneAttribution(ControlAjouterDonation controlDonation) {
        this.controlDonation = controlDonation;
        controlPersonneAttribution = new ControlAjouterPersonneAttribution(controlDonation.getGestionnaire());
    }
    

    public void ajouterPersonne(String personName, int[] startDate, int[] endDate, int sumWillingToCollect) {
       controlPersonneAttribution.ajouterPersonne(personName, startDate, endDate, sumWillingToCollect);
    }

    public ControlAjouterPersonneAttribution getControlPersonneAttribution() {
        return controlPersonneAttribution;
    }
    
}

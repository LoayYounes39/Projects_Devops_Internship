/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frontiere;

import controleur.ControlAjouterDonation;
import controleur.ControlSupprimerDonation;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author loayyounes39
 */
public class BoundarySupprimerDonation {
    
    private ControlSupprimerDonation controlSup; 
    private ControlAjouterDonation controlAj;

    public BoundarySupprimerDonation(ControlAjouterDonation controlAj) {
        this.controlAj = controlAj;
        controlSup = new ControlSupprimerDonation(controlAj.getGestionnaire());
    }

    public void supprimerDonation(String nomDonation) {
        controlSup.supprimerDonation(nomDonation);
    }
    
}

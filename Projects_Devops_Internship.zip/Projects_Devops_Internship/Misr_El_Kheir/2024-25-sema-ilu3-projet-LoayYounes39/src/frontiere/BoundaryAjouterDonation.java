/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frontiere;

import java.util.HashMap;
import javax.swing.DefaultListModel;
import controleur.ControlAjouterDonation;

/**
 *
 * @author loayyounes39
 */
public class BoundaryAjouterDonation {
    private ControlAjouterDonation controlAjouter; 

    public BoundaryAjouterDonation() {
        controlAjouter = new ControlAjouterDonation();
    }

    public void ajouterDonation(String nom, int[] dateButoir, Integer coutTotal, int identifiant) {
        controlAjouter.ajouterDonation(nom,dateButoir,coutTotal, identifiant);
    }
    
    public void ajouterPersonne(String nom, int somme){
        controlAjouter.ajouterPersonne(nom, somme);
    }

    public ControlAjouterDonation getControlAjouter() {
        return controlAjouter;
    }
    
    
}

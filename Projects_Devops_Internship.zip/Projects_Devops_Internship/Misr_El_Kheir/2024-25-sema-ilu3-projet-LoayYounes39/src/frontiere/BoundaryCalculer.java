/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frontiere;

import controleur.ControlCalculer;
import controleur.ControlAjouterDonation;
import controleur.ControlAjouterPersonneAttribution;
import entite.Donation;
import entite.Personne;
import entite.Somme;
import java.util.HashSet;
import java.util.TreeMap;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author loayyounes39
 */
public class BoundaryCalculer {
    private ControlAjouterPersonneAttribution controlAjAttr;
    private final ControlCalculer controlCalculer;

    public BoundaryCalculer(ControlAjouterPersonneAttribution controlAjAttr) {
        this.controlAjAttr = controlAjAttr;
        controlCalculer = new ControlCalculer(controlAjAttr.getGestionnaire());
    }
    
    public DefaultTableModel calculer(){
        TreeMap<Personne, Somme> mapPersonnesAjoutees = controlAjAttr.getPersonnesAjoutees();
        DefaultTableModel model = controlCalculer.calculer();
        return model;
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frontiere;

import controleur.ControlAjouterDonation;

/**
 *
 * @author loayyounes39
 */
public class BoundaryAttributionAutomatique {
    
    private BoundaryAjouterPersonneAttribution boundaryAj; 
    ControlAjouterDonation controlDonation;
    private BoundaryCalculer boundaryCalc;

    public BoundaryAttributionAutomatique(ControlAjouterDonation controlDonation) {
       boundaryAj = new BoundaryAjouterPersonneAttribution(controlDonation);
       boundaryCalc = new BoundaryCalculer(boundaryAj.getControlPersonneAttribution());
    }

    public BoundaryAjouterPersonneAttribution getBoundaryAj() {
        return boundaryAj;
    }

    public BoundaryCalculer getBoundaryCalc() {
        return boundaryCalc;
    }
    
    
    
    
    
}

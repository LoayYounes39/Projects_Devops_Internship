/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dialog;

import java.util.Arrays;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import frontiere.BoundaryAjouterDonation;
import frontiere.BoundaryAttributionAutomatique;
import frontiere.BoundarySupprimerDonation;

/**
 *
 * @author loayyounes39
 */
public class ControlleurDialog implements Iterator {

	private BoundaryAjouterDonation boundaryAj;
	private BoundarySupprimerDonation boundarySup;
	private BoundaryAttributionAutomatique boundaryAut;

	int compteurTableDonation;
	int compteurTablePersonnesDonation;
	int compteurTablePersonnesAttribution;
	int identifiantDonation;

	public int getCompteurTableDonation() {
		return compteurTableDonation;
	}

	public int getCompteurTablePersonnes() {
		return compteurTablePersonnesDonation;
	}

	public void setCompteurTableDonation(int compteurTableDonation) {
		this.compteurTableDonation = compteurTableDonation;
	}

	public void setCompteurTablePersonnes(int compteurTablePersonnes) {
		this.compteurTablePersonnesDonation = compteurTablePersonnes;
	}

	public ControlleurDialog() {
		boundaryAj = new BoundaryAjouterDonation();
		boundarySup = new BoundarySupprimerDonation(boundaryAj.getControlAjouter());
		boundaryAut = new BoundaryAttributionAutomatique(boundaryAj.getControlAjouter());
		compteurTableDonation = 0;
		compteurTablePersonnesDonation = 0;
		compteurTablePersonnesAttribution = 0;
		identifiantDonation = 1;
	}

	public void handleAjouterDonation(String nom, int[] dateButoir, Integer coutTotal, Integer remainingSum,
			DefaultTableModel modelAjoutPersonnes, JTable tableauEvenements) {
		if (remainingSum != 0) {
			String message = "Add or remove more people the remaining sum doesn't equal 0 ";
			JOptionPane.showMessageDialog(new JFrame(), message, "Dialog", JOptionPane.ERROR_MESSAGE);
		}
		DefaultTableModel modelTabEvenements = (DefaultTableModel) tableauEvenements.getModel();
		if (!contientMemeNomTableau(modelTabEvenements, nom, compteurTableDonation, 1)) {
			for (int i = 0; i < compteurTablePersonnesDonation; i++) {
				boundaryAj.ajouterPersonne((String) modelAjoutPersonnes.getValueAt(i, 0),
						(Integer) modelAjoutPersonnes.getValueAt(i, 1));
			}

			boundaryAj.ajouterDonation(nom, dateButoir, coutTotal, identifiantDonation);
			modelTabEvenements.insertRow(compteurTableDonation, new Object[] { identifiantDonation, nom, 0, coutTotal,
					Arrays.toString(dateButoir), compteurTablePersonnesDonation });
			modelTabEvenements.addTableModelListener(tableauEvenements);
			compteurTableDonation++;
			identifiantDonation++;
		} else {
			String message = "Has Donation with the same name ";
			JOptionPane.showMessageDialog(new JFrame(), message, "Dialog", JOptionPane.ERROR_MESSAGE);
		}
		compteurTablePersonnesDonation = 0;
	}

	public boolean handleAjouterPersonne(String nomPersonnne, int sommeACollecter, int sommeRestant,
			JTable tableauAjoutPersonnes) {
		int dif = sommeRestant - sommeACollecter;
		if (dif < 0) {
			String message = "The sum is less than 0";
			JOptionPane.showMessageDialog(new JFrame(), message, "Dialog", JOptionPane.ERROR_MESSAGE);
		} else {
			DefaultTableModel modelTableauAjoutPersonnes = (DefaultTableModel) tableauAjoutPersonnes.getModel();
			if (!contientMemeNomTableau(modelTableauAjoutPersonnes, nomPersonnne, compteurTablePersonnesDonation, 0)) {
				modelTableauAjoutPersonnes.insertRow(compteurTablePersonnesDonation,
						new Object[] { nomPersonnne, sommeACollecter });
				tableauAjoutPersonnes.setModel(modelTableauAjoutPersonnes);
				compteurTablePersonnesDonation++;
				return true;
			} else {
				String message = "Has Person with the same name ";
				JOptionPane.showMessageDialog(new JFrame(), message, "Dialog", JOptionPane.ERROR_MESSAGE);
			}
		}
		return false;
	}

	public DefaultTableModel handleCalculer() {
		DefaultTableModel model = boundaryAut.getBoundaryCalc().calculer();
		compteurTablePersonnesDonation = model.getRowCount();
		return model;
	}

	private boolean contientMemeNomTableau(DefaultTableModel modelTabEvenements, String nom, int compteur, int indice) {
		for (int i = 0; i < compteur; i++) {
			if (((String) modelTabEvenements.getValueAt(i, indice)).equals(nom)) {
				return true;
			}
		}
		return false;
	}

	public void handleSupprimerDonation(String nomDonation, DefaultTableModel model, int selectedRow) {
		model.removeRow(selectedRow);
		boundarySup.supprimerDonation(nomDonation);
		compteurTableDonation--;
	}

	public void handleAjouterPersonAttribution(String personName, int[] startDate, int[] endDate,
			int sumWillingToCollect, DefaultTableModel model) {
		if (!contientMemeNomTableau(model, personName, compteurTablePersonnesAttribution, 0)) {
			model.insertRow(compteurTablePersonnesAttribution, new Object[] { personName, Arrays.toString(startDate),
					Arrays.toString(endDate), sumWillingToCollect });
			boundaryAut.getBoundaryAj().ajouterPersonne(personName, startDate, endDate, sumWillingToCollect);
			compteurTablePersonnesAttribution++;
		} else {
			String message = "Has Person with the same name ";
			JOptionPane.showMessageDialog(new JFrame(), message, "Dialog", JOptionPane.ERROR_MESSAGE);
		}

	}

	@Override
	public Iterator iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Object next() {
		// TODO Auto-generated method stub
		return null;
	}
}

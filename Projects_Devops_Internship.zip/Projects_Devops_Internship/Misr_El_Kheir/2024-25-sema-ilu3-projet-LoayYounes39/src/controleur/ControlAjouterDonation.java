/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controleur;

import dao.DataAccessObject;
import entite.Donation;
import entite.DonationsTries;
import entite.GestionnaireDonations;
import entite.Personne;
import entite.Somme;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.TreeMap;
import javax.swing.DefaultListModel;

/**
 *
 * @author loayyounes39
 */
public class ControlAjouterDonation {
    private final GestionnaireDonations gestionnaire;
    private HashMap<Personne, Somme> mapPersonneSomme;
     private static final String OCAML_DIR = "OCaml";
    private static final String PERSISTENCE_ASSISTANT  = "persist";
    private static final String NAME_FILE = "donations.csv";
    private final DataAccessObject dao;


    public ControlAjouterDonation() {
        gestionnaire = new GestionnaireDonations();
        mapPersonneSomme = new HashMap<Personne, Somme>();
        dao = new DataAccessObject(OCAML_DIR, PERSISTENCE_ASSISTANT);
    }
    
    public void ajouterDonation(String nom, int[] dateButoir, int sommeTotal, int identifiant) {
        HashSet<Donation> ensDonation = gestionnaire.getEnsembleDonation();
        TreeMap<Personne, DonationsTries> mapPersonneDonations = gestionnaire.getMapPersonneDonations();
        Donation donation = new Donation(nom, dateButoir, sommeTotal, mapPersonneSomme, identifiant, false); 
        ensDonation.add(donation);
        for (Personne personne : mapPersonneSomme.keySet()) {
            if (!mapPersonneDonations.containsKey(personne)){
                DonationsTries ensembleDonationsPersonne = new DonationsTries(); 
                ensembleDonationsPersonne.add(donation);
                 mapPersonneDonations.put(personne, ensembleDonationsPersonne);
                 
            }
            else {
               DonationsTries ensembleDonationsPersonne = mapPersonneDonations.get(personne);
                ensembleDonationsPersonne.add(donation);
                mapPersonneDonations.put(personne, ensembleDonationsPersonne);
            }
        }
        gestionnaire.setEnsembleDonation(ensDonation);
        gestionnaire.setMapPersonneDonations(mapPersonneDonations);
        dao.ajouterDonationCSV(donation, NAME_FILE);
        mapPersonneSomme.clear();
    }

    public void ajouterPersonne(String nom, int somme) {
        mapPersonneSomme.put(new Personne(nom), new Somme(somme, 0));
    }

    public GestionnaireDonations getGestionnaire() {
        return gestionnaire;
    }
    

    
}

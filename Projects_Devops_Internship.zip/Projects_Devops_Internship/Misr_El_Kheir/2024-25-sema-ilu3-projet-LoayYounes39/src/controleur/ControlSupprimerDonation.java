/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controleur;

import dao.DataAccessObject;
import entite.Donation;
import entite.DonationsTries;
import entite.GestionnaireDonations;
import entite.Personne;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author loayyounes39
 */
public class ControlSupprimerDonation {

    private GestionnaireDonations gestionnaire;
    private DataAccessObject dao;
    private static final String PERSISTENCE_ASSISTANT  = "persist";
    private static final String NAME_FILE = "donations.csv";
    private static final String OCAML_DIR = "OCaml";
    
    public ControlSupprimerDonation(GestionnaireDonations gestionnaire) {
        this.gestionnaire = gestionnaire;
         dao = new DataAccessObject(OCAML_DIR, PERSISTENCE_ASSISTANT);
    }

    public void supprimerDonation(String nomDonation) {
        HashSet <Donation> ensembleDonation = gestionnaire.getEnsembleDonation();
        Iterator<Donation> donationIter = ensembleDonation.iterator();
        boolean isFound = false;
        while( ! isFound && donationIter.hasNext() ){
           Donation donation = donationIter.next();
           Set <Personne> ensemblePersonnes = donation.getMapPersonneSomme().keySet();
           if (donation.getNom().equals(nomDonation)){
               ensembleDonation.remove(donation);
               gestionnaire.setEnsembleDonation(ensembleDonation);
              TreeMap <Personne, DonationsTries> mapPersonneDonations = gestionnaire.getMapPersonneDonations();
              for (Personne personne : ensemblePersonnes){
                 DonationsTries ensembleDonationsTries = mapPersonneDonations.get(personne);
                  ensembleDonationsTries.remove(donation);
              }
           }
          isFound = true;
        }
        dao.removeDonationCSV(nomDonation, NAME_FILE);
    }
    
    
    
}

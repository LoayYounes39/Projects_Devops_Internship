/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controleur;

import dao.DataAccessObject;
import entite.Donation;
import entite.DonationsTries;
import entite.GestionnaireDonations;
import entite.Personne;
import entite.Somme;
import java.util.LinkedList;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 *
 * @author loayyounes39
 */
public class ControlAjouterPersonneAttribution {
    
    private GestionnaireDonations gestionnaire;
    private static final String OCAML_DIR = "OCaml";
    private static final String PERSISTENCE_ASSISTANT  = "persist";
    private static final String NAME_FILE = "people_before_attribution.csv";
    private DataAccessObject dao;
    private TreeMap<Personne, Somme> personnesAjoutees;

    public ControlAjouterPersonneAttribution(GestionnaireDonations gestionnaire) {
        this.gestionnaire = gestionnaire;
        dao = new DataAccessObject(OCAML_DIR, PERSISTENCE_ASSISTANT);
        personnesAjoutees = new TreeMap<Personne, Somme> ();
    }
    
    public void ajouterPersonne(String personName, int[] startDate, int[] endDate, int sumWillingToCollect) {
        StringBuilder sb = new StringBuilder();
        sb.append(personName).append(" "); 
        sb.append(sumWillingToCollect).append(" ");
        sb.append(0).append(" ");
        DonationsTries collDonations = gestionnaire.getDonationsPersonne(new Personne(personName));
        SortedSet <Donation> collDonationsDate = collDonations.chercherDonationsEntreDates(startDate, endDate);
        for (Donation donation : collDonationsDate ){
            sb.append(donation.getNom()).append(";");
        }
          String[] tabOut = dao.ajouterPersonneAttribution(sb.toString(), NAME_FILE);
          String [] donneesPersonne = tabOut[0].split(" ");
          for (String chaine : donneesPersonne){
              System.out.println(chaine);
          }
          personnesAjoutees.put(new Personne(donneesPersonne[1]), new Somme( Integer.parseInt(donneesPersonne[2]), Integer.parseInt(donneesPersonne[3]) ));
    }
    

    public TreeMap<Personne, Somme> getPersonnesAjoutees() {
        return personnesAjoutees;
    }

    public GestionnaireDonations getGestionnaire() {
        return gestionnaire;
    }
}

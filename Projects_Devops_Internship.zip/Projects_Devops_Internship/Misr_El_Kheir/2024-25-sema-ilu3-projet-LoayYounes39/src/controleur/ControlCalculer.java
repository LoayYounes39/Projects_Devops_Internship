/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controleur;

import dao.DataAccessObject;
import entite.Donation;
import entite.GestionnaireDonations;
import entite.Personne;
import entite.Somme;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeMap;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author loayyounes39
 */
public class ControlCalculer {
    HashMap <Personne, Somme> personneSumModifies = new HashMap<Personne,Somme>();
    DataAccessObject dao;
    private static final String NAME_FILE = "people_before_attribution.csv";
    private static final String OCAML_DIR = "OCaml";
    private static final String PERSISTENCE_ASSISTANT  = "persist";
    private GestionnaireDonations gestionnaire;


 
    public ControlCalculer(GestionnaireDonations gestionnaire) {
        dao = new DataAccessObject(OCAML_DIR, PERSISTENCE_ASSISTANT);
        this.gestionnaire = gestionnaire ;
    }
    
    private Donation tabChaineDonationToDonation (String[] tabChaine){
        int identifiant = Integer.parseInt(tabChaine[0]);
        String nomDon = tabChaine[1];
        int sommeCollectee = Integer.parseInt(tabChaine[2]);
        int sommeTotal = Integer.parseInt(tabChaine[3]);
        int dateButoir[] = new int[3]; 
        String[] dateButoirString = tabChaine[4].split(";");
        for (int i = 0; i < 3 ; i++){
            dateButoir[i] = Integer.parseInt(dateButoirString[i]);
        }
        HashMap <Personne, Somme> mapPersonneSommes = new HashMap<Personne, Somme>();
        String[] personnes = tabChaine[5].split("#"); 
        for (String personne1 : personnes) {
            String[] personnesDonnees = personne1.split(";");
            Personne personne = new Personne(personnesDonnees[0]);
            if (! personnesDonnees[1].equals("CollectedAll")){
                Somme somme = new Somme(Integer.parseInt(personnesDonnees[1]), Integer.parseInt(personnesDonnees[2]));
                mapPersonneSommes.put(personne, somme);
            } else {
                mapPersonneSommes.remove(personne);
            }
        }
        boolean estDonationTerminee = Boolean.parseBoolean(tabChaine[6]);
        Donation don = new Donation(nomDon, dateButoir, sommeTotal, mapPersonneSommes, identifiant, estDonationTerminee);
        don.setSommeCollecte(sommeCollectee);
        return don;
    }
    
    
    public DefaultTableModel calculer() {
        String[] donations = dao.calculer(NAME_FILE);
        HashSet <Donation> ensDonations = gestionnaire.getEnsembleDonation();
        for (String donation : donations) {
            Donation nouvDon = tabChaineDonationToDonation(donation.split(" "));
            ensDonations.add(nouvDon);
            if (nouvDon.isEstDonationTerminee()){
                ensDonations.remove(nouvDon);
            }
        }
        Iterator <Donation> itSet = ensDonations.iterator();
        DefaultTableModel model = new DefaultTableModel();
        while (itSet.hasNext()){
            Donation donation = itSet.next();
            String[] tabChaines = donation.toString().split(" ");
            tabChaines[5] = Integer.toString(donation.getMapPersonneSomme().size());
            model.addRow(Arrays.copyOfRange(tabChaines, 0, 5));         
        }
        return model;
    }

}

package dao;

import entite.Donation;
import entite.Personne;
import entite.Somme;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DataAccessObject {

    private final String path;
    private final String operator;
    private int numLigne;

    public DataAccessObject(String path, String operator) {
        numLigne = 0;
        this.path = path;
        this.operator = operator;
    }

    // Convert a Donation object to a CSV-compatible string
    private String transformerDonationFormatCSV(Donation donation) {
        numLigne++;
        return donation.toString();
    }
    
    public String[] calculer(String nomFic){
        return processCmd(operator + " -Calculate " + "-- " + nomFic);
    }
    
    public String[] ajouterPersonneAttribution(String donneesPersonneAttribution, String nomFichier){
      return processCmd(operator + " -C 1 " + donneesPersonneAttribution + " -- " + nomFichier);
  }
  
            
   public String[] removeDonationCSV(String nomDonation, String nomFichier){
       return processCmd(operator + " -D -last Nom " + nomDonation + " -- " + nomFichier);
   }

    // Add a donation to the CSV file
    public String[] ajouterDonationCSV(Donation donation, String nomFichier) {
        String donneesDonation = transformerDonationFormatCSV(donation);
        return processCmd(operator + " -C " + donneesDonation + " -- " + nomFichier);
    }

    // Read the last donation from the CSV file
    public String[] lireDerniereDonationCSV(String adresseFichier, String donnees) {
        return processCmd(operator + " -R -last " + donnees + " -- " + adresseFichier);
    }

    // Execute a command and capture its output
    private String[] processCmd(String cmd) {
        String[] params = cmd.split(" ");
        params[0] = path + File.separator + params[0];
        List<String> lines = new ArrayList<>();
        Process process;

        try {
            process = new ProcessBuilder(params).start();
            try (InputStream is = process.getInputStream();
                 InputStreamReader isr = new InputStreamReader(is);
                 BufferedReader br = new BufferedReader(isr)) {
                String line;
                while ((line = br.readLine()) != null) {
                    lines.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return lines.toArray(new String[0]);
    }


}

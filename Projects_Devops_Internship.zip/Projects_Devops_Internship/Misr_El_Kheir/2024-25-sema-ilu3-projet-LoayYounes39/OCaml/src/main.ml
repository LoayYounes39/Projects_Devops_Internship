
type personne = {nomPer : string; sommeACollecter: int; sommeDejaCollecte: int}

type progresPersonne = Sommes of int * int | ATermine

type 'b arbre = Noeud of 'b arbre * 'b * 'b arbre
              | None

type donation  =  {nomDon : string ; sommeCollectee : int ; sommeTotal : int ; date : string ; arbreProgresPersonne : (string * progresPersonne) arbre ; estDonationTerminee : bool }

type arbre_personne_ou_donation = PersonneArbre of personne arbre  | DonationArbre of donation arbre

(* fonctions d'ajout de donation *)

let rec add_element_arbre arbre element comparateur =
  match arbre with
    None -> Noeud (None, element, None)
  | Noeud (gauche, elementCourant, droite ) -> if (comparateur element elementCourant) = -1 then Noeud( (add_element_arbre gauche element comparateur) , elementCourant, droite) else if (comparateur element elementCourant ) = 1 then Noeud( gauche , elementCourant, (add_element_arbre droite element comparateur)) else arbre

let estChaineVide chaine =
  chaine = ""

let rec separerChaine chaine element liste longueur car =
  if estChaineVide chaine then
    liste
  else
    let c = String.get chaine 0 in
    if c = car then
      separerChaine (String.sub chaine 1 (longueur - 1)) "" (element :: liste) (longueur - 1) car
    else
      separerChaine (String.sub chaine 1 (longueur - 1)) (element ^ String.make 1 c) liste (longueur - 1) car


let creerDonation nom sommeCollecte sommeTotal date arbreProgresPersonne =
  {nomDon = nom; sommeCollectee = sommeCollecte; sommeTotal = sommeTotal; date = date ; arbreProgresPersonne = arbreProgresPersonne; estDonationTerminee = false}

let ajouter_personne_arbre donnees arbre =
  let comparer_personnes per perCour =
    String.compare per.nomPer perCour.nomPer in
  let personne =  match donnees with
      nom :: sommeACollecter :: []  -> {nomPer = nom; sommeACollecter = (int_of_string sommeACollecter); sommeDejaCollecte = 0} 
    | _ -> failwith "Format Données Personne : nom sommeACollecter"
  in
  PersonneArbre(add_element_arbre arbre personne (comparer_personnes))

let ajouter_donation_arbre donnees arbre =
  let comparer_donation don donCour =
    String.compare don.nomDon donCour.nomDon
  and comparer_personnes perso1 perso2 =
    String.compare (fst perso1) (fst perso2)
  in
  let ajouter_personne_progres_arbre arbre elementListe =
    let liste_donnees_personne = separerChaine elementListe "" [] (String.length elementListe) ';' in
    match liste_donnees_personne with
    | [nom; sommeACollecter; sommeDejaCollecte] ->
        add_element_arbre arbre (nom, Sommes (int_of_string sommeACollecter, int_of_string sommeDejaCollecte)) comparer_personnes 
    | _ -> failwith "Liste Données personnes nom sommeACollecter sommeDejaCollectée"
  in
  let donation = match donnees with
    | [nom; sommeCollectee; sommeTotal; date; mapPersonneSomme] ->
        let listePersonneSommeSeparees = separerChaine mapPersonneSomme "" [] (String.length mapPersonneSomme) '#' in
        let arbreProgresPersonne = List.fold_left (ajouter_personne_progres_arbre) None listePersonneSommeSeparees in
        {nomDon = nom; sommeCollectee = int_of_string sommeCollectee; sommeTotal = int_of_string sommeTotal; date = date; arbreProgresPersonne = arbreProgresPersonne; estDonationTerminee = false}
    | _ -> failwith "Format Donation : nom sommeCollectee sommeTotal date mapPersonneSomme"
  in
  DonationArbre(add_element_arbre arbre donation comparer_donation)
 
(* Définit une première procédure - programme lisant la ligne de commande *)
let main_sumavg () =

  let prog, options, args = Parse_cli.get_args () in

  (* s'il y avait un "--" dans les arguments en ligne de commande,
     ignore le découpage fait entre l1 et l2, et recolle le tout *)
  (*let all = options @ args in *)

  (* on suppose que tous les arguments sont bien des entiers et donc qu'aucune exception n'est levée *)
  let list_of_numbers = List.map int_of_string args in

  let sum, avg = Sum_avg.sum_avg list_of_numbers in

  (* un exemple de texte à afficher *)
  let text = "options = " ^ (String.concat " " options) ^ "\nsum = " ^ string_of_int sum ^ "\n"
             ^ "avg = " ^ Format.sprintf "%.2f" avg in

  print_endline text

(* Définit une autre procédure - programme lisant/écrivant un CSV *)
let main_csv_demo () =
  let chemin = Libunix.get_example_file "Promotion.csv" in
  let output = Libunix.get_example_file "Promotion_output.csv" in
  let csv = Libcsv.load_csv chemin in
  let csv' = Libcsv.map_csv (fun s -> "Super-" ^ s) csv in
  let nl, nc = Libcsv.lines_columns csv' in
  let () = Format.printf "Ecriture d'un CSV de taille (%d x %d) dans: %s\n" nl nc output in
  Libcsv.save_csv output csv'

(* Exécute les procédures précédentes *)

(*let () = main_sumavg ()

let () = main_csv_demo () *)


(* Définit une procédure qui réagit aux options positionnées :                                      *)
(* main.exe sum -- 10 20                              -> calcule somme et moyenne                   *)
(* main.exe csv -- 10 20                              -> qui lit et ecrit un csv                    *)
(* main.exe -option opt1 -option2 opt2 -- 10 20       -> affiche "The very best is comming"         *)

let main_with_options () =
  let arbre_personne = None
let arbre_donation = None 
  let prog, options, args = Parse_cli.get_args () in
  if (List.mem "Personne" options ) then ajouter_personne_arbre args arbre_personne
  else if (List.mem "Donation" options) then ajouter_donation_arbre args arbre_donation
  else failwith "commandes dispos Personne Donation "

let () = main_with_options ()

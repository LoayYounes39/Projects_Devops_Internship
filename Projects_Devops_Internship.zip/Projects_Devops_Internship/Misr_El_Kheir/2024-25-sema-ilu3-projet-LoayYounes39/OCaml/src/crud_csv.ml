(* les chemins utilisés font l'hypothèse que le projet est organisé   *)
(* sous forme de projet Java en Eclipse (avec repertoire src et bin   *)
(* auquel est rajouté un répertoire ocaml au meme niveau que src.     *)
(* Le repertoire ocaml contient lui-même un sous-repertoire ocaml-cli *)
(* qui contient lui-même un repertoire src pour les sources .ml et le *)
(* répertoire data contenant les fichiers csv.                        *)
(* Les fichiers doivent être créés (vides au minimum).*)

let data_directory = "data"

(* Concevez avec beaucoup d'attention la structure de vos données     *)


                                                                                 
let rec accederCaseLigne ligne numeroCase  =
  match ligne , numeroCase with
  | hd :: resteListe , 0 -> hd
  | hd :: resteListe , _ -> accederCaseLigne resteListe (numeroCase - 1)
  | [],_ -> failwith "La case n'est pas trouvée"


let generNumeroSelonColonneCherchee arg_list nom_fichier =
  let generateNumDonation  arg_list =
    match arg_list with
    | [endroit; "identifiant"; identifiant ] -> 1
    | [endroit; "Nom"; nom] -> 2
    | [endroit; "DateButoir"; date] -> 3
    | [endroit; "SommeCollectee"; sommeCollectee] -> 4
    | [endroit; "SommeTotal"; sommeTotal] -> 5
    | [endroit; "mapPersonneSommes"; map] -> 6
    | _ -> failwith "L'indice n'est pas trouve"
  and generateNumPersonne arg_list =
    match arg_list with
    | [endroit; "Nom"; nom] -> 1
    | [endroit; "SommeSouhaitee"; sommeSou] -> 2
    | [endroit; "SommeCollectee"; sommeCollectee] -> 3
    | [endroit; "listeNomsDonations"; listeNomsDon] -> 4
    | _ -> failwith "L'indice n'est pas trouvé "
  in 
  match nom_fichier with
  | "../donations.csv" -> generateNumDonation arg_list
  | "../people_before_attribution.csv" -> generateNumPersonne arg_list
  | "../donations_after_attribution.csv" -> generateNumDonation arg_list
  | _ -> failwith "fichier inexistant"

let inverserListe liste = List.fold_left (fun l e -> e :: l) [] liste

let fonctionDerniereLigne f donneesCSV numeroCase caseCherchee =
  let donneesInversees = inverserListe donneesCSV in
  (f donneesInversees numeroCase caseCherchee)


(* --------- CREATE ----------------*)
let create_fn arg_list csvname =
  let donneesCSV =
    try
      Libcsv.load_csv csvname
    with
    | Sys_error _ -> []
  in
   donneesCSV @ [arg_list]

(* --------- READ ----------------*)
let read_fn arg_list csvname =
  let donneesCSV =
    try
      Libcsv.load_csv csvname
    with
    | Sys_error _ -> []
  in
  let rec lirePremiereLigne donneesCSV numeroCase caseCherchee  =
    match donneesCSV with
    | hd :: resteListe ->
        if accederCaseLigne hd numeroCase = caseCherchee 
        then [hd]
        else lirePremiereLigne resteListe numeroCase caseCherchee
    | _ -> failwith "Ligne contenant l'élément recherche n'est pas trouve "
  in let lireDerniereLigne donneesCSV numeroCase caseCherchee  =
       fonctionDerniereLigne (lirePremiereLigne) donneesCSV numeroCase caseCherchee 
  in
  let rec lireTouteLigne  donneesCSV numeroCase caseCherchee =
    match donneesCSV with
    | hd :: resteListe ->
        if accederCaseLigne hd numeroCase = caseCherchee
        then hd :: lireTouteLigne resteListe numeroCase caseCherchee
        else lireTouteLigne resteListe numeroCase caseCherchee
    | [] -> []
  in
  match arg_list, donneesCSV with
  | [ "-all"] , donneesCSV -> donneesCSV
  | ["-first"; colonne; caseCherchee] , donneesCSV -> lirePremiereLigne donneesCSV (generNumeroSelonColonneCherchee arg_list csvname) caseCherchee
  | ["-last"; colonne; caseCherchee] , donneesCSV -> lireDerniereLigne donneesCSV  (generNumeroSelonColonneCherchee arg_list csvname) caseCherchee
  | ["-all"; colonne; caseCherchee] , donneesCSV -> lireTouteLigne donneesCSV (generNumeroSelonColonneCherchee arg_list csvname) caseCherchee
  | _ -> failwith "Parametres pas valides"


(* --------- DELETE ----------------*)
let delete_fn arg_list csvname =
  let donneesCSV =
    try
      Libcsv.load_csv csvname
    with
    | Sys_error _ -> []
  in
  let indice_cherche = generNumeroSelonColonneCherchee arg_list csvname
  in
  let rec supprimerPremiereLigne donneesCSV numeroCase caseCherchee =
    match donneesCSV with
    | hd :: resteListe ->
        if accederCaseLigne hd numeroCase = caseCherchee
        then resteListe
        else hd :: supprimerPremiereLigne resteListe numeroCase caseCherchee
    | _ -> failwith "Ligne contenant l'element recherche n'est pas trouve "
  in let supprimerDerniereLigne donneesCSV numeroCase caseCherchee =
       fonctionDerniereLigne (supprimerPremiereLigne) donneesCSV numeroCase caseCherchee  
  in
  let rec supprimerTouteLigne donneesCSV numeroCase caseCherchee =
    match donneesCSV with
    | hd :: resteListe ->
        if accederCaseLigne hd numeroCase = caseCherchee
        then supprimerTouteLigne resteListe numeroCase caseCherchee
        else hd :: (supprimerTouteLigne resteListe numeroCase caseCherchee)
    | [] -> []
  in
  match arg_list with
  | ["-first"; colonne; caseCherchee] -> (supprimerPremiereLigne donneesCSV indice_cherche caseCherchee)
  | ["-last"; colonne; caseCherchee] -> (supprimerDerniereLigne donneesCSV indice_cherche caseCherchee)
  | ["-all"; colonne; caseCherchee]  -> (supprimerTouteLigne donneesCSV indice_cherche caseCherchee)
  | _ -> failwith "Parametres pas valides"

          (* --------- REECRITURE ----------------*)
let reecriture_fn donneesMiseAJour nomFichier = 
  Libcsv.save_csv nomFichier donneesMiseAJour;

(* ------------ Attribution Automatique --------- *)

type personne = {nomPer : string; sommeACollecter: int; sommeDejaCollecte: int}

type progresPersonne = Sommes of int * int | ATermine 

type 'b arbre = Noeud of 'b arbre * 'b * 'b arbre
              | None

type donation  =  {identifiant : int ; nomDon : string ; sommeCollectee : int ; sommeTotal : int ; date : string ; arbreProgresPersonne : (string * progresPersonne) arbre ; estDonationTerminee : bool }

type arbre_personne_ou_donation = PersonneArbre of personne arbre  | DonationArbre of donation arbre

(* fonctions d'ajout de donation *)



let rec add_element_arbre arbre element comparateur =
  match arbre with
    None -> Noeud (None, element, None)
  | Noeud (gauche, elementCourant, droite ) -> if (comparateur element elementCourant) = -1 then Noeud( (add_element_arbre gauche element comparateur) , elementCourant, droite) else if (comparateur element elementCourant ) = 1 then Noeud( gauche , elementCourant, (add_element_arbre droite element comparateur)) else arbre

let arbre_personne_reduce_sans_repetition_premier arbre listeDonnees fnct_entite_en_elem_liste = 
  let rec arbre_reduce arbre listeDonnees =
    match arbre with
    | None -> listeDonnees
    | Noeud (g, element, d) ->
        let elem_liste = fnct_entite_en_elem_liste element in
        let listeDonneesMisAJour = elem_liste @ listeDonnees in 
        let listeDonneesMisAJourDroite = arbre_reduce g listeDonneesMisAJour in
        arbre_reduce d listeDonneesMisAJourDroite
  in
  match arbre_reduce arbre listeDonnees with
  | [] -> failwith "Arbre Vide"
  | _ :: rest -> rest 

let arbre_donation_reduce_sans_repetition_premier arbre listeDonnees fnct_entite_en_elem_liste = 
  let rec arbre_reduce arbre listeDonnees =
    match arbre with
    | None -> listeDonnees
    | Noeud (g, element, d) ->
        let elem_liste = fnct_entite_en_elem_liste element in
        let listeDonneesMisAJour = [elem_liste] @ listeDonnees in 
        let listeDonneesMisAJourGauche = arbre_reduce g listeDonneesMisAJour in
        arbre_reduce d listeDonneesMisAJourGauche
  in
  match arbre_reduce arbre listeDonnees with
  | [] -> failwith "Arbre Vide"
  | _ :: rest -> rest 

let estChaineVide chaine =
  chaine = ""

let rec separerChaine chaine element liste longueur car =
  if estChaineVide chaine then
    liste @ [element]
  else
    let c = String.get chaine 0 in
    if c = car then
      separerChaine (String.sub chaine 1 (longueur - 1)) "" (liste @ [element]) (longueur - 1) car
    else
      separerChaine (String.sub chaine 1 (longueur - 1)) (element ^ String.make 1 c) liste (longueur - 1) car


let creerPersonne nomPer sommeACollecter sommeDejaCollecte =
  {nomPer = nomPer; sommeACollecter = sommeACollecter; sommeDejaCollecte = sommeDejaCollecte}

let creerDonation identifiant nom sommeCollecte sommeTotal date arbreProgresPersonne estDonationTerminee=
  {identifiant = identifiant ; nomDon = nom; sommeCollectee = sommeCollecte; sommeTotal = sommeTotal; date = date ; arbreProgresPersonne = arbreProgresPersonne; estDonationTerminee = estDonationTerminee}

let recuperer_donations_personne row =
  match row with
  | ind :: nom :: sommeACollecter :: sommeCollectee :: donations :: []  -> separerChaine donations "" [] (String.length donations) ';'
  | _ -> failwith "Format donation "

let recuperer_couple_somme row =
  match row with
  | ind :: nom :: sommeACollecter :: sommeCollectee :: donations :: []  -> (int_of_string sommeACollecter, int_of_string sommeCollectee )
  | _ -> failwith "Format donation "

let recuperer_nom row =
  match row with
  | ind :: nom :: sommeACollecter :: sommeCollectee :: donations :: []  -> nom
  | _ -> failwith "Format donation "

let rec arbre_search arbre elementCh comparateur =
  match arbre with
  | None -> elementCh
  | Noeud (gauche, elementCour, droite) -> if (comparateur elementCh elementCour ) = -1
                                            then arbre_search gauche elementCh comparateur
                                           else if (comparateur elementCh elementCour) = 1
                                           then  arbre_search droite elementCh comparateur
                                           else elementCour 
                                         
let ajouter_donation_arbre donnees arbreDonation personneCh =
  
  let comparer_donation don donCour =
    String.compare don.nomDon donCour.nomDon
  and comparer_personnes personneFormatProgres1 personneFormatProgres2 =
    String.compare (fst personneFormatProgres1) (fst personneFormatProgres2) 

 in let  ajouter_personne_progres_arbre arbreProgres elementListe =
    let liste_donnees_personne = separerChaine elementListe "" [] (String.length elementListe) ';' in
    match liste_donnees_personne with
    | [nom; sommeACollecter; sommeDejaCollecte] ->
        add_element_arbre arbreProgres (nom, Sommes (int_of_string sommeACollecter, int_of_string sommeDejaCollecte)) (comparer_personnes) 
    | _ -> failwith "Liste Données personnes nom sommeACollecter sommeDejaCollectée"

 in let rec modifier_arbre_progres arbre_progres personneCh =
  match arbre_progres with
  | None -> (None, personneCh)
  | Noeud (gauche, (nom, progres), droite) ->
      let comparaison = comparer_personnes (personneCh.nomPer, progres) (nom,progres) in
      if comparaison = -1 then
        let (g, personne_modifiee) = modifier_arbre_progres gauche personneCh in
        (Noeud (g, (nom, progres), droite), personne_modifiee)
      else if comparaison = 1 then
        let (d, personne_modifiee) = modifier_arbre_progres droite personneCh in
        (Noeud (gauche, (nom, progres), d), personne_modifiee)
      else
        let (nouveau_progres, somme_utilisee) =
          match progres with
          | Sommes (sommeACollecte, sommeCollecte) ->
              if sommeACollecte - sommeCollecte <= personneCh.sommeACollecter - personneCh.sommeDejaCollecte then
                (ATermine, sommeACollecte - sommeCollecte)
              else
                (Sommes (sommeACollecte, sommeCollecte + (personneCh.sommeACollecter - personneCh.sommeDejaCollecte)),
                 personneCh.sommeACollecter - personneCh.sommeDejaCollecte)
          | ATermine -> (ATermine, 0)
        in
        let personne_modifiee =
          creerPersonne personneCh.nomPer personneCh.sommeACollecter (personneCh.sommeDejaCollecte + somme_utilisee)
        in
        (Noeud (gauche, (nom, nouveau_progres), droite), personne_modifiee)
    in
 
  let donation = match donnees with
    | [identifiant ;nom; sommeCollectee; sommeTotal; date; mapPersonneSomme; estDonationTerminee] ->
        let listePersonneSommeSeparees = separerChaine mapPersonneSomme "" [] (String.length mapPersonneSomme) '#' in
        let arbreProgresPersonne = List.fold_left (ajouter_personne_progres_arbre) None listePersonneSommeSeparees in
        ( arbre_search arbreDonation
            (creerDonation (int_of_string identifiant) nom (int_of_string sommeCollectee) (int_of_string sommeTotal) date arbreProgresPersonne (bool_of_string estDonationTerminee)) comparer_donation)
    | _ -> failwith "Format Donation : nom sommeCollectee sommeTotal date mapPersonneSomme"
  in
  let couple_arbre_progres_modifie = modifier_arbre_progres donation.arbreProgresPersonne personneCh
  in let donationModifie =
       let personne_modifiee = snd couple_arbre_progres_modifie
       in let nouvelle_somme_donation = donation.sommeCollectee + (  (personne_modifiee.sommeDejaCollecte) - personneCh.sommeDejaCollecte )
          in let estTermine = nouvelle_somme_donation >= donation.sommeTotal
           in if estTermine
              then creerDonation donation.identifiant donation.nomDon donation.sommeTotal donation.sommeTotal donation.date (fst couple_arbre_progres_modifie) estTermine
              else creerDonation donation.identifiant donation.nomDon nouvelle_somme_donation donation.sommeTotal donation.date (fst couple_arbre_progres_modifie) estTermine
           in
  let nouvArbreDonation = add_element_arbre arbreDonation donationModifie comparer_donation
  in DonationArbre( nouvArbreDonation )


let ajouter_donations_personne arbreCons row =
  let ajouter_donation_arbre_chaine (arbreCons, personneCh) nomDon =
    let donnees = read_fn ["-first"; "Nom"; nomDon] "../donations.csv" in
    match donnees with
    | [] -> failwith ("No data found for donation: " ^ nomDon)
    | liste_donnees_donation :: _ ->
        match arbreCons with
        | DonationArbre ab ->
            (ajouter_donation_arbre liste_donnees_donation ab personneCh, personneCh)
        | PersonneArbre _ ->
            failwith "Expected a DonationArbre, got a PersonneArbre"
  in
  let personneCh =
    creerPersonne
      (recuperer_nom row)
      (fst (recuperer_couple_somme row))
      (snd (recuperer_couple_somme row))
  in
  let liste_donations_personne = recuperer_donations_personne row in
  fst (List.fold_left ajouter_donation_arbre_chaine (arbreCons, personneCh) liste_donations_personne)

let traiter_toutes_personnes donneesCSVPersonnes =
  List.fold_left ajouter_donations_personne (DonationArbre None) donneesCSVPersonnes

let calculate_fn crud_args filename =
  let personne_sommes_to_Liste_Java couple_progres_personne =
    match couple_progres_personne with
    | (nom, Sommes (sommeACollecter, sommeCollectee)) ->
        nom
        :: string_of_int sommeACollecter
        :: string_of_int sommeCollectee
        :: []
    | (nom, ATermine) -> nom :: "CollectedAll" :: "CollectedAll" :: []
  in
  let donation_to_Liste_Java donation =
    string_of_int donation.identifiant
    :: donation.nomDon
    :: string_of_int donation.sommeCollectee
    :: string_of_int donation.sommeTotal
    :: donation.date
    :: List.fold_left
         (fun chaine hd -> chaine ^ hd ^ ";")
         "#"
         (arbre_personne_reduce_sans_repetition_premier
            donation.arbreProgresPersonne
            []
            personne_sommes_to_Liste_Java
            )
    :: string_of_bool donation.estDonationTerminee
    :: []
  in
  let donneesCSV = read_fn ["-all"] filename in
  let arbre_toutes_donations = traiter_toutes_personnes donneesCSV in
  let arbre_toutes_donations_val_cons = match arbre_toutes_donations with
      DonationArbre(ab) -> ab
    | PersonneArbre(_) -> failwith "arbre personne"
  in
  arbre_donation_reduce_sans_repetition_premier arbre_toutes_donations_val_cons [] donation_to_Liste_Java 

 

(* Exemples de tests unitaires de la commande de persistance sur *)
(* un domaine gerant des etudiants, epreuves, modules...         *)
(*
./persist -C 1 Migeon Frederic False -- etudiants.csv
./persist -C 1 CC1 1 KINXIL11 -- epreuves.csv
./persist -C 1 ILU1 6 -- modules.csv

./persist -R -all -- etudiants.csv
./persist -R -first Nom Migeon -- etudiants.csv
./persist -R -last Nom Migeon -- etudiants.csv

./persist -U -all Nom Migeon Migeo -- etudiants.csv
./persist -U -first Nom Migeo Migeon -- etudiants.csv
./persist -U -last Nom Migeo Migeon -- etudiants.csv
./persist -D -all Nom Migeon -- etudiants.csv
./persist -D -first Nom Migeon -- etudiants.csv
./persist -D -last Nom Migeon -- etudiants.csv

 *)    

#include <getopt.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Partie1/cle_symetrique.h"
#include "list.h"
#include "Partie3/break_code_all.h" 

#define MAX_FILE_NAME 100

char* printList(char* cle, void* env){
    (void)env;
	printf("%s \n", cle);
	return cle;
}

char* my_strdupFinal(const char* s) { 
    char* d = malloc(strlen(s) + 1);
    if (d == NULL) return NULL; 
    strcpy(d, s); 
    return d; 
}

char* read_key_from_file(const char *filename, size_t *len) {
    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("Error opening key file");
        return NULL;
    }

    fseek(file, 0, SEEK_END);
    *len = ftell(file);
    rewind(file);

    char *key = (char *)malloc(*len + 1);
    if (!key) {
        perror("malloc");
        fclose(file);
        return NULL;
    }

    if (fread(key, 1, *len, file) != *len) {
        perror("fread");
        free(key);
        fclose(file);
        return NULL;
    }
    key[*len] = '\0';

    fclose(file);
    return key;
}

void help(){
    printf("help donne la liste des commandes \n");
    printf("list-keys : donne la liste des clefs générées et disponibles et indique celle qui ont déjà été utilisées \n");
    printf ("gen-key <n> : génère une clef de longueur n \n");
    printf("del-key <key> : supprime la clef <key> \n");
    printf("encrypt <in> <out> <method> [<key>] [<vecteur d'initialisation>] : pas de cle pour la methode mask mais cle obligatoire pour les methodes CBC et XOR\n");
    printf("decrypt <in> <out> <method> <key> [<vecteur d'initialisation>] \n");
    printf("crack <in> <length> <dico> \n");
    printf("quit \n");
}

// Fonction mise à jour
char* openFilesFunction(char* nom_fic_in, char* nom_fic_out, unsigned long* file_size, FILE** input_fp, FILE** output_fp) {
    *input_fp = fopen(nom_fic_in, "rb");
    if (!*input_fp) {
        perror("fopen in");
        exit(1);
    }
    if (output_fp != NULL) {
        *output_fp = fopen(nom_fic_out, "wb");
        if (!*output_fp) {
            perror("fopen out");
            fclose(*input_fp);
            exit(1);
        }
    }

    fseek(*input_fp, 0, SEEK_END);
    *file_size = ftell(*input_fp);
    rewind(*input_fp);

    char* data = (char *)malloc(*file_size + 1);
    if (!data) {
        perror("malloc");
        fclose(*input_fp);
        if (output_fp != NULL) {
            fclose(*output_fp);
        }
        exit(1);
    }

    if (fread(data, 1, *file_size, *input_fp) != *file_size) {
        perror("fread");
        free(data);
        fclose(*input_fp);
        if (output_fp != NULL) {
            fclose(*output_fp);
        }
        exit(1);
    }

    data[*file_size] = '\0';
    return data;
}

int main(void){
    // Variable globale , elle est une constante mais modifiable quand l'utilisateur veut générer une clée plus longue que max_command_length
    int max_command_length = 1000;
    int estTermine = 0;
    List * list_cle_generees = list_create();
    List * list_cle_utilisees = list_create();
    char* cmd = calloc(max_command_length,sizeof(char));
    if(!cmd){
        perror("cmd Calloc");
        exit(EXIT_FAILURE);
    }
    char sous_cmd[7] = {0};
    int n_gen_key = -1;

    help();

    while ( ! estTermine  ) {
        printf(">");
        if ( fgets(cmd, max_command_length, stdin) == NULL) {
            fprintf(stderr, "Erreur lors de la lecture de l'entrée.\n");
            free(cmd);
            list_delete(&list_cle_generees);
            list_delete(&list_cle_utilisees);
            exit(1);
        }
        cmd[strcspn(cmd, "\n")] = '\0';

        if (strncmp(cmd, "help", strlen("help")) == 0){
            help();
        } else if (strncmp(cmd, "quit",strlen("quit")) == 0 ){
            estTermine = 1;
            // Donner la liste des clées générées 

        } else if (strncmp(cmd, "list-keys",strlen("list-keys")) == 0){
            void * env = NULL;
            printf("***** La liste des clées générées ****** \n");
            list_cle_generees =  list_map(list_cle_generees, printList, env);
            printf("***** La liste des clées déjà utilisées ****** \n"); 
            list_cle_utilisees = list_map(list_cle_utilisees, printList, env );

        } else if (sscanf(cmd, "%s %d", sous_cmd, &n_gen_key) == 2){
            if (strncmp(sous_cmd, "gen-key", strlen("gen-key")) == 0){
                char* cle = gen_key(n_gen_key);
                printf("La clée générée %s \n" , cle);
                int p = 0;
                if (! list_in(list_cle_generees, cle, &p)){
                    list_cle_generees =  list_push_back(list_cle_generees, cle);
                } 
                if (n_gen_key > max_command_length){
                    max_command_length = max_command_length + n_gen_key;
                }
                free(cle);
            }
        } else if (strncmp(cmd, "del-key", strlen("del-key")) == 0) {
            int longueur_cle = max_command_length - strlen("del-key");
            char* cle_to_delete = malloc(sizeof(char) * longueur_cle);
            if (!cle_to_delete) { 
                perror("malloc cle_to_delete"); 
                free(cmd); 
                list_delete(&list_cle_generees); 
                list_delete(&list_cle_utilisees); 
                exit(EXIT_FAILURE); 
            }
            strncpy(cle_to_delete, cmd + 8, longueur_cle-1);
            int p = 0; 
            if (list_in(list_cle_generees, cle_to_delete, &p)){
               list_cle_generees = list_remove_at(list_cle_generees, p);
            }
            if (list_in(list_cle_utilisees, cle_to_delete, &p)){
                list_cle_utilisees = list_remove_at(list_cle_utilisees, p);
            }
            free(cle_to_delete);

        } else if (strncmp(cmd, "encrypt", strlen("encrypt")) == 0 || strncmp(cmd, "decrypt", strlen("decrypt")) == 0)  {
            char nom_fic_in[MAX_FILE_NAME] = {0}; 
            char nom_fic_out[MAX_FILE_NAME] = {0}; 
            char* cle = (char*)calloc(max_command_length, sizeof(char));
            if(!cle){
                perror("calloc cle");
                free(cmd); 
                list_delete(&list_cle_generees); 
                list_delete(&list_cle_utilisees);
                exit(EXIT_FAILURE);
            }
            char methode[12] = {0};
            char* vecteur_init = calloc(max_command_length,sizeof(char));
            if(!vecteur_init){
                perror("calloc cle");
                free(cle);
                free(cmd); 
                list_delete(&list_cle_generees); 
                list_delete(&list_cle_utilisees);
                exit(EXIT_FAILURE);
            }
            unsigned long file_size = 0;
            FILE* input_file = NULL; 
            FILE* output_file = NULL;
            char* result = NULL;
            int is_file = 0;
            
            //Si la méthode est cbc_crypt
            if (sscanf(cmd, "encrypt %s %s %s %s %s ", nom_fic_in, nom_fic_out, methode, cle, vecteur_init ) == 5){
                if (strcmp(methode, "cbc_crypt") == 0) {
                    char *key_data = cle;
                    cbc_crypt(nom_fic_in,nom_fic_out,key_data,vecteur_init,strlen(key_data),8);
                    fprintf(stdout, "cbc encryption  completed on %s to %s\n", nom_fic_in, nom_fic_out);
                }
                else {
                    free(cle);
                    free(cmd);
                    free(vecteur_init);
                    list_delete(&list_cle_generees);
                    list_delete(&list_cle_utilisees);
                    perror("Methode Inexistant ");
                    exit(3);
                }
            // Si la méthode est cbc_uncrypt
            } else if (sscanf(cmd, "decrypt %s %s %s %s %s ", nom_fic_in, nom_fic_out, methode, cle, vecteur_init ) == 5){
                if (strncmp(methode, "cbc_uncrypt", strlen("cbc_uncrypt")) == 0) {
                    char *key_data = cle;
                    printf("nom fichier : %s \n", nom_fic_in);
                    cbc_uncrypt(nom_fic_in,nom_fic_out,key_data,vecteur_init,strlen(key_data),8);
                    fprintf(stdout, "cbc uncryption  completed on %s to %s\n", nom_fic_in, nom_fic_out);
                } else {
                    free(cle);
                    free(cmd);
                    free(vecteur_init);
                    list_delete(&list_cle_generees);
                    list_delete(&list_cle_utilisees);
                    perror("Méthode Inexistant "); 
                    exit(3);
                } 
            // Si la méthode est une autre méthode qui n'a pas besoin de vecteur d'initialisation 
            } else if ((strncmp(cmd, "encrypt", strlen("encrypt")) == 0 && (
            sscanf(cmd, "encrypt %s %s %s", nom_fic_in, nom_fic_out, methode) == 3)) ||
            (strncmp(cmd, "decrypt", strlen("decrypt")) == 0 && sscanf(cmd, "decrypt %s %s %s %s", nom_fic_in, nom_fic_out, methode, cle) == 4)) {
                char *data = openFilesFunction(nom_fic_in, nom_fic_out, &file_size, &input_file, &output_file);
                if (strcmp(methode, "xor") == 0) {
                    size_t key_len = 0;
                    char *key = NULL;
                    
                    // Vérifier si la clé est un fichier existant
                    FILE *file = fopen(cle, "r");
                    if (file) {
                        fclose(file);
                        is_file = 1;
                        key = read_key_from_file(cle, &key_len);
                        if (!key) { 
                            perror("read_key_from_file"); 
                            free(data); 
                            fclose(input_file); 
                            fclose(output_file);
                            free(cmd);
                            free(vecteur_init);
                            list_delete(&list_cle_generees);
                            list_delete(&list_cle_utilisees);
                            exit(EXIT_FAILURE);
                        }
                    } else {
                        key = my_strdupFinal(cle);
                        if (!key) { 
                            perror("strdup"); 
                            free(data); 
                            fclose(input_file); 
                            fclose(output_file); 
                            free(cmd);
                            free(vecteur_init);
                            list_delete(&list_cle_generees);
                            list_delete(&list_cle_utilisees);
                            exit(EXIT_FAILURE); 
                        }
                        key_len = strlen(cle);
                    }

                    result = xor(data, key, file_size, key_len);
                    free(key);
                } else if (strncmp(cmd, "encrypt", strlen("encrypt")) == 0 && strcmp(methode, "mask") == 0) {
                    result = mask(data, file_size, "mask_key.txt");
                } else {
                    free(cle);
                    free(cmd);
                    free(vecteur_init);
                    list_delete(&list_cle_generees);
                    list_delete(&list_cle_utilisees);
                    free(data);
                    perror("Méthode inexistante");
                    exit(3);
                }

                // Écriture du résultat dans un fichier
                if (fwrite(result, 1, file_size, output_file) != file_size) {
                    perror("fwrite");
                }
                free(result);
                free(data);
                fclose(input_file);
                fclose(output_file);
            } else {
                if (strncmp(cmd, "encrypt", strlen("encrypt")) == 0){
                    free(cle);
                    free(cmd);
                    free(vecteur_init);
                    list_delete(&list_cle_generees);
                    list_delete(&list_cle_utilisees);
                    perror ("Usage encrypt <in> <out> <method> [<key>] [<vecteur d'initialisation>] : pas de cle pour la methode mask mais cle obligatoire pour les methodes CBC et XOR");
                    exit(4);
                } else {
                    free(cle);
                    free(cmd);
                    free(vecteur_init);
                    list_delete(&list_cle_generees);
                    list_delete(&list_cle_utilisees);
                    perror("Usage decrypt <in> <out> <method> <key> [<vecteur d'initialisation>]"); 
                    exit(4);
                }
            }
            int p = 0;
            char* cle_a_ajouter = malloc(sizeof(strlen(cle)));
            if(!cle_a_ajouter){
                free(cle);
                free(cmd);
                free(vecteur_init);
                list_delete(&list_cle_generees);
                list_delete(&list_cle_utilisees);
                perror("cle_a_ajouter malloc");
                exit(EXIT_FAILURE);
            }
            if(!is_file) { 
                strcpy(cle_a_ajouter,cle);
                if (! list_in(list_cle_utilisees, cle_a_ajouter, &p)){
                    list_cle_utilisees = list_push_back(list_cle_utilisees, cle_a_ajouter);
                }
            }
            is_file = 0;
            FILE *log_fp = stdout;
            fprintf(log_fp, "Operation %s completed successfully on %s to %s\n", methode, nom_fic_in, nom_fic_out);
            free(vecteur_init);
            free(cle);
            free(cle_a_ajouter);

        } else if (strncmp(cmd, "crack", strlen("crack")) == 0){
            char nom_fic_in[MAX_FILE_NAME] = {0}; 
            int longueur_cle = 0;
            char nom_dico[MAX_FILE_NAME] = {0};
            if (sscanf(cmd, "crack %s %d %s", nom_fic_in, &longueur_cle, nom_dico) == 3){
                char * data = NULL;
                unsigned long file_size = 0; 
                FILE* input_file = NULL; 
                data = openFilesFunction(nom_fic_in, NULL, &file_size, &input_file, NULL);
                printf("C3 attack launched...\n");
                break_code_c3(data, longueur_cle, nom_dico);
                fprintf(stdout, "C3 method completed. \n");
                fclose(input_file);
                free(data);
            } else if (sscanf(cmd , "crack %s %d", nom_fic_in, &longueur_cle) == 2){
                char * data;
                unsigned long file_size = 0; 
                FILE* input_file = NULL; 
                data = openFilesFunction(nom_fic_in, NULL, &file_size, &input_file, NULL);
                char nom_methode[2] = {0};
                printf("tappez C1 pour crack C1 ou C2 pour crack C2 \n"); 
                if (scanf("%2s", nom_methode) != 1) {
                    free(cmd);
                    list_delete(&list_cle_generees);
                    list_delete(&list_cle_utilisees);
                    fprintf(stderr, "Erreur lors de la lecture de l'entrée.\n"); 
                    exit(1); 
                }
                if (strncmp(nom_methode, "C1", strlen("C1"))==0){
                    printf("C1 attack launched...\n"); 
                    break_code_c1(data, longueur_cle);
                    fprintf(stdout, "C1 method completed. \n");
                } else if (strncmp(nom_methode, "C2", strlen("C2")) == 0) {
                    printf("C2 attack launched...\n");
                    break_code_c2(data, strlen(data), longueur_cle);
                    fprintf(stdout, "C2 method completed. \n");
                }
                fclose(input_file);
                free(data);
            } else {
                free(cmd);
                list_delete(&list_cle_generees);
                list_delete(&list_cle_utilisees);
                perror("Usage crack <in> <out> <length> <dico> \n");
                exit(5);
            }
        }  
    }
    free(cmd);
    list_delete(&list_cle_generees);
    list_delete(&list_cle_utilisees);
    return 0; 
}





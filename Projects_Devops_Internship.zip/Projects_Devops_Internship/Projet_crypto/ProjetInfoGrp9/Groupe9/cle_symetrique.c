#include <stdio.h>
#include <stdlib.h>  
#include <string.h>
#include "cle_symetrique.h"

char* xor(char *message, char* key, int lenMessage, int lenKey) {   
    char* crypt = malloc(lenMessage);
    int i_key = 0;
    for (int i =0 ; i < lenMessage; i++) { 
        crypt[i] = message[i]^key[i_key];

        i_key = (i_key+1)%lenKey;

    }
    return crypt;
}

char* gen_key(int lenKey) {
    char* key = malloc(sizeof(char)*lenKey+1);
    for(int i =0;i<lenKey;i++) {
        key[i] = rand()%95+32;  
    }
    key[lenKey] = '\0';
    return key;
}

char* mask(char* message, int lenMessage, const char * filename) {
    char* key = gen_key(lenMessage);
    FILE *file = fopen(filename, "wb");

    if (file != NULL) {
        fwrite(key, sizeof(char), lenMessage, file); 
        fclose(file);
        printf("Clé enregistrée dans le fichier : %s\n", filename);
    } else {
        printf("Erreur lors de l'ouverture du fichier pour écrire la clé.\n");
        free(key);
        return NULL;
    }

    char* encrypted_message = xor(message, key, lenMessage , lenMessage);

    free(key);
    
    return encrypted_message; 
}

void cbc_crypt(const char* nameFileToEncrypted, const char* nameFileRes, char* key, char* vector, int lenKey, int lenBloc){
    char* curr = malloc(sizeof(char)*lenBloc);
    if(!curr){
        perror("Impossible memory allocation");
        exit(EXIT_FAILURE);
    }
    char *cryptedCurr = malloc(sizeof(char)*lenBloc);
    if(!cryptedCurr){
        perror("Impossible memory allocation");
        free(curr);
        exit(EXIT_FAILURE);
    }
    FILE *fileRes = fopen(nameFileRes,"wb");
    if(!fileRes){
        perror("Write file cannot be opened");
        free(curr);
        free(cryptedCurr);
        exit(EXIT_FAILURE);
    }
    FILE *fileToEncrypted = fopen(nameFileToEncrypted,"rb");
    if(!fileToEncrypted){
        perror("Read file cannot be opened");
        free(curr);
        free(cryptedCurr);
        fclose(fileRes);
        exit(EXIT_FAILURE);
    }

    size_t buffer;
    while ((buffer = fread(curr,1,lenBloc,fileToEncrypted)) > 0){
        for (unsigned i = 0; i < buffer; i++){
            cryptedCurr[i] = curr[i]^vector[i];
        }
        char* new_vector = xor(cryptedCurr, key, buffer, lenKey);
        memcpy(vector, new_vector, buffer);
        free(new_vector);
        fwrite(cryptedCurr, 1, buffer, fileRes);
    }
    
    fclose(fileRes);
    fclose(fileToEncrypted);
    free(curr);
    free(cryptedCurr);
}

void cbc_uncrypt(const char* nameFileToDecrypted, const char* nameFille, char* key, char* vector, int lenKey, int lenVector, int lenBloc) {
    char* curr = malloc(sizeof(char) * lenBloc);
    if(!curr) {
        perror("Impossible memory allocation");
        exit(EXIT_FAILURE);
    }
    char *cryptedCurr = malloc(sizeof(char) * lenBloc);
    if(!cryptedCurr) {
        perror("Impossible memory allocation");
        free(curr);
        exit(EXIT_FAILURE);
    }
    char * decryptedCurr = malloc(sizeof(char) * lenBloc);
    if(!decryptedCurr) {
        perror("Impossible memory allocation");
        free(curr);
        free(cryptedCurr);
        exit(EXIT_FAILURE);
    }
    FILE *fileToDecrypted = fopen(nameFileToDecrypted, "rb");
    if(!fileToDecrypted) {
        perror("Write file cannot be opened");
        exit(EXIT_FAILURE);
    }
    FILE *fileRes = fopen(nameFille, "w");
    if(!fileRes) {
        fclose(fileToDecrypted);
        perror("Read file cannot be opened");
        exit(EXIT_FAILURE);
    }
    size_t buffer;
    while ((buffer = fread(curr, 1, lenBloc, fileRes)) > 0) {
        char* cryptedCurr = xor(curr, key, buffer, lenKey);
        for (unsigned i = 0; i < buffer; i++) {
            decryptedCurr[i] = cryptedCurr[i] ^ vector[i];
        }
        memcpy(vector, curr, buffer);
        fwrite(decryptedCurr, 1, buffer, fileToDecrypted);
        free(cryptedCurr);
    }

    fclose(fileToDecrypted);
    fclose(fileRes);
    free(curr);
    free(cryptedCurr);
    free(decryptedCurr);
}


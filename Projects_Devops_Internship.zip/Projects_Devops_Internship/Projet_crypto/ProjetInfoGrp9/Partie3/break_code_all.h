#ifndef BREAK_CODE_ALL_H
#define BREAK_CODE_ALL_H

void break_code_c1(char *texte_chiffre, int taille_cle);
void break_code_c2(char *ciphertext, size_t cipher_len, size_t key_length);
void break_code_c3(char *texte_chiffre, int taille_cle, char *fichier_dictionnaire);

#endif 
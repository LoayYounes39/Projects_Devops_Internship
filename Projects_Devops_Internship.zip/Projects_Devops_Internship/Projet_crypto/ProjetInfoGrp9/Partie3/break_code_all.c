#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

#define MAX_SIZE_KEY 256
#define ASCII_PRINTABLE_START 32
#define ASCII_PRINTABLE_FINE 126
#define MAX_SIZE_WORD 128

char* my_strdupPartie3(const char* s) { 
	char* d = malloc(strlen(s) + 1);
	if (d == NULL) return NULL;
	strcpy(d, s); 
	return d; 
}

// Function XOR
char* xor2(char *message, char* key, int lenMessage, int lenKey) {
    char* crypt = malloc(lenMessage + 1); // +1 for the null terminator
    int i_key = 0;
    for (int i = 0; i < lenMessage; i++) {
        char encrypted_char = message[i] ^ key[i_key];
        // Ensures that the character is printable
        encrypted_char = ((encrypted_char - ASCII_PRINTABLE_START) % (ASCII_PRINTABLE_FINE - ASCII_PRINTABLE_START + 1)) + ASCII_PRINTABLE_START;
        crypt[i] = encrypted_char;
        i_key = (i_key + 1) % lenKey;
    }
    crypt[lenMessage] = '\0'; // End the chain
    return crypt;
}

// Check whether a character is valid (printable ASCII and certain special characters)
int is_ascii_valid(char c) {
    return (c >= ASCII_PRINTABLE_START && c <= ASCII_PRINTABLE_FINE) ||
        c == '\n' || c == '\r' || c == '\t' || 
        c == '\v' || c == '\b' || c == '\f' || 
        c == '\a' || c == 27;
}

// Generate all possible key combinations (cartesian product)
void generate_keys(int size_key, char valid_characters[MAX_SIZE_KEY][ASCII_PRINTABLE_FINE - ASCII_PRINTABLE_START + 1], int nb_valid_characters[MAX_SIZE_KEY], int current_pos, char *current_key, char **res, int *res_index) {
    if (current_pos == size_key) {
        memmove(res[*res_index], current_key, strlen(current_key) + 1);
        (*res_index)++;
        return;
    }
    for (int i = 0; i < nb_valid_characters[current_pos]; i++) {
        current_key[current_pos] = valid_characters[current_pos][i];
        generate_keys(size_key, valid_characters, nb_valid_characters, current_pos + 1, current_key, res, res_index);
    }
}

// Retrieve the table of candidate keys
char** find_keys_C1(char *encrypted_text, int size_key, int *res_index) {
    int length_number = strlen(encrypted_text);
    char valids_characters[MAX_SIZE_KEY][ASCII_PRINTABLE_FINE - ASCII_PRINTABLE_START + 1];
    int nb_valids_characters[MAX_SIZE_KEY] = {0};

    // Find the valid characters for each key position
    for (int i = 0; i < size_key; i++) {
        for (char candidat = ASCII_PRINTABLE_START; candidat <= ASCII_PRINTABLE_FINE; candidat++) {
            int is_valid = 1;
            for (int j = i; j < length_number; j += size_key) {
                char uncrypted = encrypted_text[j] ^ candidat;
                if (!is_ascii_valid(uncrypted)) {
                    is_valid = 0;
                    break;
                }
            }
            if (is_valid) {
                valids_characters[i][nb_valids_characters[i]++] = candidat;
            }
        }
    }

    int max_keys = 1;
    for (int i = 0; i < size_key; i++) {
        max_keys *= nb_valids_characters[i];
    }

    char **res = malloc(max_keys * sizeof(char *));
    for (int i = 0; i < max_keys; i++) {
        res[i] = malloc((size_key + 1) * sizeof(char));
    }

    char current_key[MAX_SIZE_KEY + 1];
    current_key[size_key] = '\0'; // End the chain

    generate_keys(size_key, valids_characters, nb_valids_characters, 0, current_key, res, res_index);
    
    return res;
}

// Decrypt and write the results to a file
void break_code_c1(char *encrypted_text, int size_key) {
    int res_index = 0;
    char **keys = find_keys_C1(encrypted_text, size_key, &res_index);

    FILE *results_file = fopen("decrypted_results_C1.txt", "w");
    if (results_file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    // Test each key and write the decrypted message to the file
    for (int i = 0; i < res_index; i++) {
        char *decrypted_message = xor2(encrypted_text, keys[i], strlen(encrypted_text), size_key);
        fprintf(results_file, "Decrypting key %s:\n%s\n\n", keys[i], decrypted_message);
        free(decrypted_message);
    }

    fclose(results_file);
    printf("The decrypted results were written to the file decrypted_results_C1.txt\n");

    // Free up allocated memory
    for (int i = 0; i < res_index; i++) {
        free(keys[i]);
    }
    free(keys);
}

// Frequency of letters in English
const double english_freq[] = {
    8.167, 1.492, 2.782, 4.253, 12.702, 2.228, 2.015, 6.094, 6.966, 0.153, 
    0.772, 4.025, 2.406, 6.749, 7.507, 1.929, 0.095, 5.987, 6.327, 9.056, 
    2.758, 0.978, 2.360, 0.150, 1.974, 0.074
};

// Convert a character to an index from 0 to 25
int char_to_index(char c) {
    if (c >= 'a' && c <= 'z') return c - 'a';
    if (c >= 'A' && c <= 'Z') return c - 'A';
    return -1; // No alphabet
}

// Calculate the distance between two frequency distributions
double calculate_distance(const double *freq1, const double *freq2) {
    double distance = 0.0;
    for (int i = 0; i < 26; i++) {
        distance += pow(freq1[i] - freq2[i], 2);
    }
    return distance;
}

// Find keys with a score below a certain threshold
void find_best_keys_c2(char **keys, int res_index, char *ciphertext, size_t cipher_len, size_t key_length, double threshold, char ***best_keys, int *num_best_keys) {
    *num_best_keys = 0;
    *best_keys = malloc(res_index * sizeof(char*));
    if (*best_keys == NULL) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < res_index; i++) {
        char *candidate_key = keys[i];

        // Decoding the text
        char *decoded = xor2((char *)ciphertext, candidate_key, cipher_len, key_length);

        // Calculate letter frequencies ignoring punctuation and spaces
        double freq[26] = {0};
        size_t total_letters = 0;
        int penalty = 0;

        for (size_t j = 0; j < cipher_len; j++) {
            char c = decoded[j];
            if (isalpha(c)) {  // Count only the letters
                int idx = char_to_index(c);
                if (idx != -1) {
                    freq[idx]++;
                    total_letters++;
                }
            } else if (!isspace(c) && !ispunct(c)) {
                penalty++;  // Penalising non-alphabetic and non-punctuation characters
            } else if (j > 0 && (ispunct(decoded[j-1]) && ispunct(c))) {
                penalty += 5;  // Penalising punctuation sequences
            }
        }

        // Calculate the score taking into account the frequency distance and the total number of letters
        double freq_score = calculate_distance(english_freq, freq);
        double total_score = freq_score / (total_letters + 1) + penalty;  // Favour messages containing more letters and penalise non-alphabetic characters

        if (total_score < threshold) {
            (*best_keys)[*num_best_keys] = my_strdupPartie3(candidate_key);
            if ((*best_keys)[*num_best_keys] == NULL) {
                perror("my_strdupPartie3");
                exit(EXIT_FAILURE);
            }
            (*num_best_keys)++;
        }

        free(decoded); // Free up the memory allocated to each decrypted message
    }
}

// Implement the C2 attack and write the results to a file
void break_code_c2(char *ciphertext, size_t cipher_len, size_t key_length) {
    int res_index = 0;
    // Use the keys generated by C1
    char **keys = find_keys_C1(ciphertext, key_length, &res_index);

    FILE *results_file = fopen("decrypted_results_C2.txt", "w");
    if (results_file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    char **best_keys;
    int num_best_keys;
    double threshold = cipher_len*(key_length+1)-1;  // Setting the threshold

    // Find the best keys using frequency analysis and a threshold
    find_best_keys_c2(keys, res_index, ciphertext, cipher_len, key_length, threshold, &best_keys, &num_best_keys);

    // Decrypt with the best keys and write to the file
    for (int i = 0; i < num_best_keys; i++) {
        char *decrypted_message = xor2((char *)ciphertext, best_keys[i], cipher_len, key_length);
        fprintf(results_file, "Candidate key : %s\nMessage decrypted :\n%s\n\n", best_keys[i], decrypted_message);
        free(decrypted_message);
        free(best_keys[i]);
    }

    free(best_keys);
    fclose(results_file);

    // Free up memory allocated for keys
    for (int i = 0; i < res_index; i++) {
        free(keys[i]);
    }
    free(keys);

    printf("The decrypted results were written to the file decrypted_results_C2.txt\n");
}

// Function for loading a dictionary
int load_dictionary(const char *name_file, char dictionary[][MAX_SIZE_WORD], int max_word) {
    FILE *fichier = fopen(name_file, "r");
    if (!fichier) {
        perror("Error opening file dictionary");
        return -1;
    }
    int compte = 0;
    while (fgets(dictionary[compte], MAX_SIZE_WORD, fichier) && compte < max_word) {
        dictionary[compte][strcspn(dictionary[compte], "\n")] = '\0'; // Remove newline

        char *start = dictionary[compte];
        while (isspace((unsigned char)*start)) start++;
        
        char *end = start + strlen(start);
        if (end > start) {
            end--;
            while (end > start && isspace((unsigned char)*end)) end--;
        }
        *(end + 1) = '\0';

        // Use memmove only if start is not equal to dictionary[compte]
        if (start != dictionary[compte]) {
            memmove(dictionary[compte], start, strlen(start) + 1);
        }
        
        compte++;
    }
    fclose(fichier);
    return compte;
}

// Function for checking whether a word is in the dictionary
int is_in_dictionary(const char *word, char dictionary[][MAX_SIZE_WORD], int dictionary_size) {
    for (int i = 0; i < dictionary_size; i++) {
        if (strcmp(word, dictionary[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

// Function for splitting text into words and converting words to lower case
void cut_into_words(char *texte, char words[][MAX_SIZE_WORD], int *nb_words) {
    *nb_words = 0;
    char *word = strtok(texte, " \n\r\t.,;:!?'\"()-&%");

    while (word != NULL && *nb_words < 1000) {
        // Convert to lower case and keep only letters between [97, 122]
        char *src = word;
        char *dest = word;
        while (*src) {
            if (*src >= 'A' && *src <= 'Z') {
                *dest = *src + ('a' - 'A');  // Convert to lower case
            } else if (*src >= 'a' && *src <= 'z') {
                *dest = *src;
            } else {
                src++;
                continue;
            }
            src++;
            dest++;
        }
        *dest = '\0';  // End the chain

        // Add the cleaned word to the list
        if (strlen(word) > 0) {
            memmove(words[*nb_words], word, strlen(word) + 1);  // Utilisez memmove pour gérer les chevauchements de mémoire
            (*nb_words)++;
        }
        word = strtok(NULL, " \n\r\t.,;:!?'\"()-&%");
    }
}

// Function for implementing the C3 attack using the results of C2
void break_code_c3(char *encrypted_text, int size_key, const char *fichier_dictionary) {
    char dictionary[2048][MAX_SIZE_WORD];
    int dictionary_size = load_dictionary(fichier_dictionary, dictionary, 2049);
    if (dictionary_size <= 0) {
        fprintf(stderr, "Dictionary loading failed.\n");
        exit(EXIT_FAILURE);
    }

    int res_index = 0;
    // Use the keys generated by C1
    char **keys_c1 = find_keys_C1(encrypted_text, size_key, &res_index);

    // Finding the best keys using frequency analysis
    char **best_keys_c2;
    int num_best_keys_c2;
    find_best_keys_c2(keys_c1, res_index, encrypted_text, strlen(encrypted_text), size_key, strlen(encrypted_text)*(size_key+1)-1, &best_keys_c2, &num_best_keys_c2);

    char best_key[MAX_SIZE_KEY];
    int best_score = 0;

    for (int i = 0; i < num_best_keys_c2; i++) {
        char *candidate_key = best_keys_c2[i];

        // Decoding the text
        char *decoded = xor2((char *)encrypted_text, candidate_key, strlen(encrypted_text), size_key);

        // Cut the decoded text into words
        char words[1000][MAX_SIZE_WORD];
        int nb_words = 0;
        cut_into_words(decoded, words, &nb_words);

        // Check the words in the deciphered text
        int score = 0;
        for (int j = 0; j < nb_words; j++) {
            if (is_in_dictionary(words[j], dictionary, dictionary_size)) {
                score++;
            }
        }
        if (score > best_score) {
            best_score = score;
            memmove(best_key, candidate_key, strlen(candidate_key) + 1);
        }

        free(decoded); // Free up the memory allocated to each decrypted message
    }

    FILE *results_file = fopen("decrypted_results_C3.txt", "wb");
    if (results_file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    char *decrypted_message = xor2((char *)encrypted_text, best_key, strlen(encrypted_text), size_key);

    if (decrypted_message != NULL) {
        fprintf(results_file, "The best key is %s (score : %d) :\nMessage decrypted :\n%s\n", best_key, best_score, decrypted_message);
        printf("The decrypted results were written to the file decrypted_results_C3.txt\n");
        fflush(results_file);
        free(decrypted_message);
    } else {
        fprintf(stderr, "Erreur lors du déchiffrement du message.\n");
    }

    for (int i = 0; i < num_best_keys_c2; i++) {
        free(best_keys_c2[i]);
    }
    free(best_keys_c2);

    fclose(results_file);

    for (int i = 0; i < res_index; i++) {
        free(keys_c1[i]);
    }
    free(keys_c1);
}

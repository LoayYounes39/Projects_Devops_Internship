#ifndef CLE_SYMETRIQUE_H
#define CLE_SYMETRIQUE_H

char* xor(char *message, char* key, int lenMessage, int lenKey);

char* gen_key(int lenKey);

char* mask(char* message, size_t lenMessage, const char* filename);

void cbc_crypt(const char* nameFileToEncrypted, const char* nameFileRes, char* key, char* vector, int lenKey, int lenBloc);

void cbc_uncrypt(const char* nameFileToDecrypted, const char* nameFileRes, char* key, char* vector, int lenKey, int lenBloc);

#endif 

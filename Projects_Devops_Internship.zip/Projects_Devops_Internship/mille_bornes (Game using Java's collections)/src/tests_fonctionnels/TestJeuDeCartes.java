package tests_fonctionnels;

import cartes.JeuDeCartes;

public class TestJeuDeCartes {
	public static void main(String[] args) {
        JeuDeCartes jc = new JeuDeCartes();
        System.out.println(jc.affichageJeuDeCartes());
        System.out.println(jc.checkCount());
        
	}
	
	
}

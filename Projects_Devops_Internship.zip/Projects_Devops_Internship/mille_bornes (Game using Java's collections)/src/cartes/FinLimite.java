package cartes;

public class FinLimite extends Limite {

	public FinLimite() {
		super();
	}

	@Override
	public String toString() {
		return "Fin Limite ";
	}

}

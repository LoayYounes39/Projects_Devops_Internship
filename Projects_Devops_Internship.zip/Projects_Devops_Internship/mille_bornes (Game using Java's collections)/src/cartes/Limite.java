package cartes;

public abstract class Limite extends Carte {
}


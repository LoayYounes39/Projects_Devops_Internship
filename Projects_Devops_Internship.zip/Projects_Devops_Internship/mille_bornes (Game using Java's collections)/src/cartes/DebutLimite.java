package cartes;

public class DebutLimite extends Limite {

	public DebutLimite() {
		super();	}

	@Override
	public String toString() {
		return "Limite 50";
	}

}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <ctype.h>
#include "break_code_all.h"


void show_help() {
    printf("Usage: break_code -i file-to-decrypt -m method -k key-length [-d dictionary] [-l logfile]\n");
    printf("Options :\n");
    printf("  -i file-to-decrypt      Specifies the file containing the ciphertext.\n");
    printf("  -m method               Method to be used: c1 for C1 method, c2 for C2 method and c3 for C3 method.\n");
    printf("  -k key-length           Key length.\n");
    printf("  -d dictionary           Dictionary file (mandatory if -m c3 is selected).\n");
    printf("  -l logfile              File for recording attack results.\n");
    printf("  -h                      Display this help.\n");
}

char *load_file(const char *file_name) {
    FILE *file = fopen(file_name, "r");
    if (!file) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    rewind(file);

    char *content = malloc(size + 1);
    if (!content) {
        perror("Memory allocation error");
        exit(EXIT_FAILURE);
    }

    fread(content, 1, size, file);
    content[size] = '\0';
    fclose(file);
    return content;
}

void save_log(FILE *logfile, const char *message) {
    if (logfile) {
        fprintf(logfile, "%s\n", message);
    }
}


int main(int argc, char *argv[]) {
    // Variables for storing options
    char *file_to_decrypt = NULL;
    char *method = NULL;
    char *dictionary_file = NULL;
    FILE *logfile = NULL;
    int key_length = 0;

    // Analyse des options
    int option;
    while ((option = getopt(argc, argv, "i:m:k:d:l:h")) != -1) {
        switch (option) {
            case 'i':
                file_to_decrypt = optarg;
                break;
            case 'm':
                method = optarg;
                break;
            case 'k':
                key_length = atoi(optarg);
                break;
            case 'd':
                dictionary_file = optarg;
                break;
            case 'l':
                logfile = fopen(optarg, "a");
                if (!logfile) {
                    perror("Error opening log file");
                    exit(EXIT_FAILURE);
                }
                break;
            case 'h':
                show_help();
                return 0;
            default:
                show_help();
                exit(EXIT_FAILURE);
        }
    }

    // Validation of compulsory options
    if (!file_to_decrypt || !method || key_length <= 0) {
        fprintf(stderr, "Error: options -i, -m and -k are mandatory.\n");
        show_help();
        exit(EXIT_FAILURE);
    }

    // Upload the file to be decrypted
    char *encrypted_text = load_file(file_to_decrypt);

    // Launch methods
    if (strcmp(method, "c1") == 0) {
        printf("C1 attack launched...\n"); 
        break_code_c1(encrypted_text, key_length);
        if (logfile) save_log(logfile, "C1 method completed.");
    } 
    else if (strcmp(method, "c2") == 0) {
        printf("C2 attack launched...\n");
        break_code_c2(encrypted_text, strlen(encrypted_text), key_length);
        if (logfile) save_log(logfile, "C2 method completed.");
    }
    else if(strcmp(method, "c3") == 0){
        printf("C3 attack launched...\n");
        if(!dictionary_file){
            fprintf(stderr, "Error: options -i, -m, -k and -d are mandatory.\n");
            show_help();
            if (logfile) fclose(logfile); 
            exit(EXIT_FAILURE);
        }
        break_code_c3(encrypted_text, key_length, dictionary_file);
        if (logfile) save_log(logfile, "C3 method completed.");
    }
    else {
        fprintf(stderr, "Error : invalid method. Use c1 or c2 or c3.\n");
        show_help();
        free(encrypted_text);
        if (logfile) fclose(logfile);  // Close the log file before quitting
        exit(EXIT_FAILURE);
    }

    // Freeing memory and closing the log file
    free(encrypted_text);
    if (logfile) fclose(logfile);
    printf("Programme successfully completed.\n");
    return 0;
}


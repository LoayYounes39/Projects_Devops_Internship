import random
import math
import queue
from threading import Thread
import argparse

def Alice (queueAlice, queueBob, premier, generateur, logAlice):
  a = random.randint(1, premier-1)
  A = pow(generateur, a, premier)
  queueBob.put(A)
  queueBob.put(A)
  B = queueAlice.get(block=True, timeout=None)
  cle_secrete = pow(B, a, premier)
  logAlice.write("La cle secrete de Alice est : "+str(cle_secrete)+ "\n")
  print("La cle secrete de Alice est : "+str(cle_secrete)+ "\n")

def Bob (queueAlice, queueBob, premier, generateur, logAlice):
  b = random.randint(1, premier-1)
  B = pow(generateur, b, premier)
  queueAlice.put(B)
  queueAlice.put(B)
  A= queueBob.get(block=True, timeout=None)
  cle_secrete = pow(A,b,premier)
  logAlice.write("La cle secrete de Bob est : "+str(cle_secrete)+ "\n")
  print("La cle secrete de Bob est : "+str(cle_secrete)+ "\n")

def Eve (queueAlice, queueBob, premier, logAlice) :
  c = random.randint(1, premier-1)
  B = queueAlice.get(block=True, timeout=None)
  logAlice.write("Alice a recu : " +str(B)+'\n')
  A = queueBob.get(block=True, timeout=None)
  logAlice.write("Bob a recu : " +str(A)+'\n')
  key = pow(B,c, premier)
  logAlice.write("Eve a trouve : " +str(key))
  print("Eve : j'ai trouvé que la clé est " +str(key))

def lire_parametres(fichier):
    with open(fichier, 'r') as f:
        lines = f.readlines()
        premier = int(lines[0].split('=')[1].strip().split()[0])
        generateur = int(lines[1].split('=')[1].strip().split()[0])
    return premier, generateur

def main():
  # py echange_Diffie_Hellman.py -o nom_du_fichier.txt
  # python3 echange_Diffie_Hellman.py -o nom_du_fichier.txt

  parser = argparse.ArgumentParser(description="Diffie-Hellman Key Exchange Simulation")
  parser.add_argument('-o', '--fichier', type=str, required=True, help='File containing premier and generateur')
  args = parser.parse_args()

  p, g = lire_parametres(args.fichier)

  logAlice = open("logAlice.txt", "w")

  queueAlice = queue.Queue()
  queueBob = queue.Queue()

  alice_thread = Thread(target=Alice, args=(queueAlice, queueBob, p, g, logAlice))
  bob_thread = Thread(target=Bob, args=(queueAlice, queueBob, p, g, logAlice))
  eve_thread = Thread(target=Eve, args=(queueAlice, queueBob, p, logAlice))

  alice_thread.start()
  bob_thread.start()
  eve_thread.start()

  alice_thread.join()
  bob_thread.join()
  eve_thread.join()
  logAlice.close

if __name__ == "__main__":
  main()




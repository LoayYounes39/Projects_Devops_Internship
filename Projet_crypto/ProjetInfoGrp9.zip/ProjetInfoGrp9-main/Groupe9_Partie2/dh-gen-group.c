#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <assert.h>
#include <time.h>
#include "dh_prime.h"

void print_help_message() {
    printf("Usage: dh_gen_group -o <output_file> | -h\n");
    printf("Options:\n");
    printf("  -o <output_file>  Specify the output file to write the generated prime number and generator.\n");
    printf("  -h                Display this help message and exit.\n");
}

int main(int argc, char *argv[]) {
    int opt;
    char *file = NULL;

    while ((opt = getopt(argc, argv, "o:h")) != -1) {
        switch (opt) {
            case 'h':
                print_help_message();
                exit(0);
            case 'o':
                file = optarg;
                break;
            default:
                fprintf(stderr, "Invalid option: %c\n", opt);
                fprintf(stderr, "Usage: %s -o <output_file> | -h\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }

    FILE *file_p = stdout;
    if (file) {
        file_p = fopen(file, "w");
        if (!file_p) {
            perror("Erreur fopen");
            exit(EXIT_FAILURE);
        }
    } else {
        fprintf(stderr, "Give the file name\n");
        fprintf(stderr, "Usage: %s -o <output_file> | -h\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    srand(time(NULL));

    generate_shared_key(file_p, 1000000, 2000000);

    fclose(file_p);

    return 0;
}



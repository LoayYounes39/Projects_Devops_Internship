#include <stdio.h>
#include <stdlib.h>
#include "cle_symetrique.h"
#include <string.h>
#include <getopt.h>

static char *usage_message = "Usage: ./sym_crypt -i input_file -o output_file -k key OR -f key_file -m method -v initialization_vector [-l log_file] [-h]";

void print_help_message(){
    printf("-i suivi du nom de fichier contenant le message à chiffrer [obligatoire] \n ");
    printf("-o suivi du nom de fichier vers lequel on écrit le message [obligatoire] et si le fichier n'existe pas , le message est écrit vers un nouveau fichier \n ");
    printf ("-m suivi du nom de la méthode : soit xor , cbc_uncrypt , cbc_crypt, ou mask \n -k suivi de la clé obligatoire en absence de -f  et ne peut pas être utilisée avec -f");
    printf("-f suivi du : \n 1. Nom de fichier contenant la clée avec laquelle crypter le message \n 2. Nom du fichier dans lequel jeter la clée avec la méthode mask \n obligatoire en absence de -k  et ne peut pas être utilisée avec -k ");
    printf("-v suivi du vecteur d'initialisation , obligatoire lors du choix des méthodes cbc_crypt ou cbc_uncrypt , et il ne faut pas l'utiliser avec les autres méthodes \n");
    printf("-l suivi du nom de fichier sur lequel vont être écrits les logs des différents actions effectués dans le programme \n");
    printf("-h commande d'aide , si utilisée tout le reste des commandes ne sont pas obligatoires et ne vont pas être pris en compte. \n");
} 

char* readKey(char* name){
    FILE *key_fp = fopen(name, "rb");
    if (!key_fp) {
        perror("fopen");
        exit(1);
    }

    fseek(key_fp, 0, SEEK_END);
    long key_file_size = ftell(key_fp);
    rewind(key_fp);

    char* key_data = malloc(key_file_size + 1);
    if (!key_data) {
        perror("malloc");
        fclose(key_fp);
        exit(1);
    }

    if (fread(key_data, 1, key_file_size, key_fp) != key_file_size) {
        perror("fread");
        free(key_data);
        fclose(key_fp);
        exit(1);
    }
    key_data[key_file_size] = '\0';

    fclose(key_fp);
    return key_data;
}

int main(int argc, char *argv[]) {
    int opt;
    char *input_file = NULL, *output_file = NULL, *key = NULL, *key_file = NULL, *method = NULL, *iv = NULL, *log_file = NULL;

    while ((opt = getopt(argc, argv, "i:o:k:f:m:v:l:h")) != -1) {
        switch (opt) {
            case 'h':
                print_help_message();
                exit(0);
            case 'i':
                input_file = optarg;
                break;
            case 'o':
                output_file = optarg;
                break;
            case 'k':
                key = optarg;
                break;
            case 'f':
                key_file = optarg;
                break;
            case 'm':
                method = optarg;
                break;
            case 'v':
                iv = optarg;
                break;
            case 'l':
                log_file = optarg;  
                break;
            default:
                fprintf(stderr, "Invalid option: %c\n", opt);
                fprintf(stderr, "%s\n", usage_message);
                exit(1);
        }
    }

    if (!input_file || !output_file || !method) {
        fprintf(stderr, "Missing required arguments.\n");
        fprintf(stderr, "%s\n", usage_message);
        exit(1);
    }

    FILE *log_fp = stdout; //stdout par defaut si le fichier du log n'est pas present
    if (log_file) {
        log_fp = fopen(log_file, "wa");
        if (!log_fp) {
            perror("fopen");
            exit(1);
        }
    }


    // Utilisation de XOR ou Mask
     if (strcmp(method, "xor") == 0 || strcmp(method, "mask") == 0) {
        if(strcmp(method, "mask") == 0 && !key_file){
            fprintf(stderr,"Required key file\n");
            exit(1);
        }

        FILE *input_fp = fopen(input_file, "rb");
        if (!input_fp) {
            perror("fopen");
            exit(1);
        }

        FILE *output_fp = fopen(output_file, "wb");
        if (!output_fp) {
            perror("fopen");
            fclose(input_fp);
            exit(1);
        }

        fseek(input_fp, 0, SEEK_END);
        long file_size = ftell(input_fp);
        rewind(input_fp);

        char *data = (char *)malloc(file_size + 1);
        if (!data) {
            perror("malloc");
            fclose(input_fp);
            fclose(output_fp);
            exit(1);
        }

        if (fread(data, 1, file_size, input_fp) != file_size) {
            perror("fread");
            free(data);
            fclose(input_fp);
            fclose(output_fp);
            exit(1);
        }
        data[file_size] = '\0';

        char *result = NULL;

        if(strcmp(method, "xor") == 0){
            char *key_data = NULL;
            if(key) key_data = key;
            else if(key_file) key_data = readKey(key_file);
            else{
                fprintf(stderr,"Required Key\n");
                exit(1);
            }
        
            result = xor(data, key_data, file_size, strlen(key_data)+1);
        }

        if(strcmp(method, "mask") == 0){
            result = mask(data,file_size,key_file);
        }

        if (fwrite(result, 1, file_size, output_fp) != file_size) {
            perror("fwrite");
        }

        fprintf(log_fp, "Operation %s completed successfully on %s to %s\n", method, input_file, output_file);

        free(data);
        free(result);

        fclose(input_fp);
        fclose(output_fp);
    } 
    else if (strcmp(method, "cbc_crypt") == 0 || strcmp(method, "cbc_uncrypt") == 0) {
        if ((!key && !key_file) || !iv) {
            fprintf(stderr, "Key and initialization vector are required for CBC mode.\n");
            exit(1);
        }

        char* key_data = NULL;
        if(key) key_data = key;
        else if(key_file) key_data = readKey(key_file);

        if (strcmp(method, "cbc_crypt") == 0) {
            cbc_crypt(input_file,output_file,key_data,iv,strlen(key_data),8);
            fprintf(log_fp, "cbc encryption  completed on %s to %s\n", input_file, output_file);
        } else {
            cbc_uncrypt(input_file,output_file,key_data,iv,strlen(key_data),8);
            fprintf(log_fp, "cbc decryption completed on %s to %s\n", input_file,output_file);
        }
        
    } 
    else {
        fprintf(stderr, "Invalid method: %s\n", method);
        exit(1);
    }

    if (log_fp != stdout) fclose(log_fp);
    return 0;
}
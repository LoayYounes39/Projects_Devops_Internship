#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "list.h"

char* my_strdup(const char* s) { 
	char* d = malloc(strlen(s) + 1); // +1 pour le '\0' de fin de chaîne 
	if (d == NULL) return NULL; // En cas d'erreur d'allocation 
	strcpy(d, s); 
	return d; 
}
typedef struct s_LinkedElement {
    char* cle;
    struct s_LinkedElement* previous;
    struct s_LinkedElement* next;
} LinkedElement;

/* Use of a sentinel for implementing the list :
 The sentinel is a LinkedElement* whose next pointer refers always to the head of the list and previous pointer to the tail of the list
 */
struct s_List {
    int size;
    LinkedElement* sentinel;
};
/*-----------------------------------------------------------------*/

List* list_create(void) {
    List* l = malloc(sizeof(struct s_List));
    if (l == NULL) {
        perror("malloc");
        exit(1);
    }
    l->sentinel = malloc(sizeof(struct s_LinkedElement));
    if (l->sentinel == NULL) {
        perror("malloc");
        free(l);
        exit(1);
    }
    // Initialize the sentinel to point to itself
    l->sentinel->previous = l->sentinel;
    l->sentinel->next = l->sentinel;
    l->size = 0;
    l->sentinel->cle = "";
    return l;
}

/*-----------------------------------------------------------------*/

void list_delete(ptrList* l) {
    while (!list_is_empty(*l)) {
        list_pop_back(*l);
    }
    free((*l)->sentinel);
    free(*l);
}

/*-----------------------------------------------------------------*/

List* list_push_front(List* l, char* cle) {
    LinkedElement* new_elem = malloc(sizeof(LinkedElement));
    new_elem->cle = my_strdup(cle);
    new_elem->next = l->sentinel->next;
    new_elem->previous = l->sentinel;
    new_elem->next->previous = new_elem;
    l->sentinel->next = new_elem;
    l->size++;
    return l;
}

/*-----------------------------------------------------------------*/

char* list_front(const List* l) {
    assert(!list_is_empty(l));
    return l->sentinel->next->cle;
}

/*-----------------------------------------------------------------*/

char* list_back(const List* l) {
    assert(!list_is_empty(l));
    return l->sentinel->previous->cle;
}

/*-----------------------------------------------------------------*/

List* list_pop_front(List* l) {
    assert(!list_is_empty(l));
    LinkedElement* to_remove = l->sentinel->next;
    to_remove->next->previous = l->sentinel;
    l->sentinel->next = to_remove->next;
    free(to_remove->cle); // Free the allocated string
    free(to_remove);
    l->size--;
    return l;
}

/*-----------------------------------------------------------------*/

List* list_push_back(List* l, char* cle) {
    LinkedElement* new_elem = malloc(sizeof(LinkedElement));
    new_elem->cle = my_strdup(cle);
    new_elem->previous = l->sentinel->previous;
    new_elem->next = l->sentinel;
    new_elem->previous->next = new_elem;
    l->sentinel->previous = new_elem;
    l->size++;
    return l;
}

/*-----------------------------------------------------------------*/

List* list_insert_at(List* l, int p, char* cle) {
    LinkedElement* cur = l->sentinel;
    for (; p > 0; p--) {
        cur = cur->next;
    }
    LinkedElement* new_elem = malloc(sizeof(LinkedElement));
    new_elem->cle = my_strdup(cle);
    new_elem->previous = cur;
    new_elem->next = cur->next;
    cur->next = new_elem;
    new_elem->next->previous = new_elem;
    l->size++;
    return l;
}

/*-----------------------------------------------------------------*/

List* list_pop_back(List* l) {
    assert(!list_is_empty(l));
    LinkedElement* to_remove = l->sentinel->previous;
    to_remove->previous->next = l->sentinel;
    l->sentinel->previous = to_remove->previous;
    free(to_remove->cle);
    free(to_remove);
    l->size--;
    return l;
}

/*-----------------------------------------------------------------*/

List* list_remove_at(List* l, int p) {
    LinkedElement* cur = l->sentinel;
    for (; p > 0; p--) {
        cur = cur->next;
    }
    LinkedElement* to_remove = cur->next;
    to_remove->previous->next = to_remove->next;
    to_remove->next->previous = to_remove->previous;
    free(to_remove->cle);
    free(to_remove);
    l->size--;
    return l;
}

/*-----------------------------------------------------------------*/

char* list_at(const List* l, int p) {
    LinkedElement* cur = l->sentinel;
    for (; p >= 0; p--) {
        cur = cur->next;
    }
    return cur->cle;
}

/*-----------------------------------------------------------------*/

bool list_is_empty(const List* l) {
    return l->size == 0;
}

/*-----------------------------------------------------------------*/

int list_size(const List* l) {
    return l->size;
}

/*-----------------------------------------------------------------*/

List* list_map(List* l, ListFunctor f, void* environment) {
    for (LinkedElement* cur = l->sentinel->next; cur != l->sentinel; cur = cur->next) {
        cur->cle = f(cur->cle, environment);
    }
    return l;
}

int list_in(List* l, const char* cle, int* pos) {
    *pos = 0;
    LinkedElement* cur = l->sentinel->next;
    while (cur != l->sentinel) {
        if (strcmp(cur->cle, cle) == 0) {
            return 1;
        }
        cur = cur->next;
        (*pos)++;
    }
    return 0;
}

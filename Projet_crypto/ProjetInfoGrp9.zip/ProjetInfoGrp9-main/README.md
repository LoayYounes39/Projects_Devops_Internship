Au cours de ce projet, nous avons développé un logiciel de cryptographie symétrique composé de trois parties distinctes, ainsi qu'un programme global permettant d'exécuter plusieurs commandes.

Déroulement du projet :

    Première partie :
        Nous avons rencontré un problème dans la fonction "cbc_uncrypt" où les huit premiers caractères ne se décryptaient pas correctement. Après analyse, nous avons découvert que cela était dû à une mauvaise initialisation du vecteur dans la fonction principale (main). Une fois ce problème corrigé, la première partie fonctionne correctement.

    Deuxième partie :
        Cette partie s'est déroulée sans encombre. Nous n'avons rencontré aucun problème, et le programme fonctionne parfaitement.

    Troisième partie : 
        Cette partie a été un peu plus complexe. Au début, nous avions du mal à comprendre les exigences, mais après clarification, nous avons développé avec succès les fonctions c1, c2 et c3. Les trois fichiers sont correctement créés, la clé est trouvée, et le message est bien déchiffré à l'aide de cette clé. Le processus de décryptage a donc été mené à bien.

Logiciel final :

Comme il nous restait du temps, nous avons développé un logiciel final regroupant les trois parties précédentes, tout en permettant l'exécution de commandes supplémentaires.

Compilation du programme :

    make DEBUG=yes "nom_executable"

        Remplacez "nom_executable" par :

            sym_crypt pour la première partie.

            dh_gen pour la deuxième partie.

            break_code pour la troisième partie.

            final pour le logiciel global.

Fonctionnalités du logiciel final :

    help : Affiche la liste des commandes disponibles.

    list-keys : Affiche la liste des clés générées et disponibles, en précisant celles déjà utilisées.

    gen-key <n> : Génère une clé de longueur n.

    del-key <key> : Supprime la clé spécifiée.

    encrypt <in> <out> <method> [<key>] [<vecteur d'initialisation>] : Crypte un fichier. La clé n'est pas obligatoire pour la méthode MASK, mais elle est requise pour CBC et XOR.

    decrypt <in> <out> <method> <key> [<vecteur d'initialisation>] : Décrypte un fichier.

    crack <in> <length> <dico> : Tente de casser le chiffrement en utilisant un dictionnaire.

    quit : Quitte le logiciel.

Ce projet nous a permis de mieux comprendre les concepts liés à la cryptographie symétrique et de développer un outil fonctionnel et complet.

